const router = require('express').Router()
const fs = require('fs')
const path = require('path')
const pool = require('../config/db')
const auth = require('../middleware/auth')
const {
  buildLearningPathPayload,
  findTaskDefinition,
  getPreviousTaskIds,
  getUploadTaskIdForFeedbackTask,
  isFeedbackTask,
  isUploadTask,
  readMeta,
} = require('../lib/learningPath')
const {
  ensureStudentFeedbackTable,
  persistFeedbackAttachments,
  sanitizeFeedbackSource,
} = require('../lib/studentFeedback')

router.use(auth('student'))

const DEFAULT_UPLOADS_DIR = path.join(__dirname, '../../uploads')
const UPLOADS_DIR = process.env.UPLOADS_DIR
  ? path.resolve(process.env.UPLOADS_DIR)
  : DEFAULT_UPLOADS_DIR

const CHECKPOINT_NAME_ALIASES = [
  ['英语提分冲刺班', '要点不全不准'],
  ['英语阅读精练班', '提炼转述困难'],
  ['数学压轴突破班', '对策推导困难'],
  ['数学基础巩固班', '公文结构不清'],
  ['语文写作提升班', '作文立意不准'],
  ['阅读定位', '要点不全不准'],
  ['阅读理解', '要点不全不准'],
  ['主旨题', '提炼转述困难'],
  ['阅读专项', '提炼转述困难'],
  ['数列综合', '对策推导困难'],
  ['数学压轴突破', '对策推导困难'],
  ['函数讨论', '分析结构不清'],
  ['书面表达', '作文表达不畅'],
  ['议论文结构', '作文论证不清'],
  ['函数基础', '公文结构不清'],
  ['计算规范', '作文表达不畅'],
]

const REVIEW_POINT_LIST = [
  { id: 1, pointName: '要点不全不准' },
  { id: 2, pointName: '提炼转述困难' },
  { id: 3, pointName: '分析结构不清' },
  { id: 4, pointName: '公文结构不清' },
  { id: 5, pointName: '对策推导困难' },
  { id: 6, pointName: '作文立意不准' },
  { id: 7, pointName: '作文论证不清' },
  { id: 8, pointName: '作文表达不畅' },
]

const REVIEW_POINT_STATUS_PRIORITY = {
  learning: 0,
  completed: 1,
  pending: 2,
  locked: 3,
}

function isMissingTableError(error) {
  return error && error.code === 'ER_NO_SUCH_TABLE'
}

function mergeLearningPathMeta(previousMeta = {}, patch = {}) {
  const nextMeta = {
    ...previousMeta,
    ...patch,
  }

  if (patch.appointment && typeof patch.appointment === 'object') {
    nextMeta.appointment = {
      ...(previousMeta.appointment || {}),
      ...patch.appointment,
    }
  }

  if (patch.rating && typeof patch.rating === 'object') {
    nextMeta.rating = {
      ...(previousMeta.rating || {}),
      ...patch.rating,
    }
  }

  if (patch.result && typeof patch.result === 'object') {
    nextMeta.result = {
      ...(previousMeta.result || {}),
      ...patch.result,
    }
  }

  if (patch.resource && typeof patch.resource === 'object') {
    nextMeta.resource = {
      ...(previousMeta.resource || {}),
      ...patch.resource,
    }
  }

  if (Array.isArray(patch.uploads)) {
    nextMeta.uploads = patch.uploads
  }

  return nextMeta
}

async function loadLearningPathRows(studentId, pointName) {
  const [rows] = await pool.query(
    `SELECT id, stage_key, task_id, is_done, meta_json, updated_at
     FROM student_learning_path_tasks
     WHERE student_id = ? AND point_name = ?
     ORDER BY id ASC`,
    [studentId, pointName]
  )
  return rows
}

async function buildStudentLearningPath(studentId, pointName) {
  const safePointName = normalizeCheckpointName(pointName)
  const rows = await loadLearningPathRows(studentId, safePointName)
  return buildLearningPathPayload(studentId, safePointName, rows.map((row) => ({
    ...row,
    status: Number(row.is_done) ? 'done' : 'pending',
  })))
}

async function saveLearningPathTask({
  studentId,
  pointName,
  stageKey,
  taskId,
  status,
  metaPatch,
  actorRole,
  actorId,
}) {
  const safePointName = normalizeCheckpointName(pointName)
  const [[existingRow]] = await pool.query(
    `SELECT id, meta_json, is_done
     FROM student_learning_path_tasks
     WHERE student_id = ? AND point_name = ? AND stage_key = ? AND task_id = ?
     LIMIT 1`,
    [studentId, safePointName, stageKey, taskId]
  )

  let mergedMeta = mergeLearningPathMeta({}, metaPatch)
  if (existingRow && existingRow.meta_json) {
    try {
      const parsedMeta = JSON.parse(existingRow.meta_json)
      mergedMeta = mergeLearningPathMeta(parsedMeta && typeof parsedMeta === 'object' ? parsedMeta : {}, metaPatch)
    } catch {
      mergedMeta = mergeLearningPathMeta({}, metaPatch)
    }
  }

  const nextDone = status === 'pending' || status === 'current'
    ? 0
    : 1

  await pool.query(
    `INSERT INTO student_learning_path_tasks (
       student_id, point_name, stage_key, task_id, is_done, meta_json, updated_by_role, updated_by_id
     ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
     ON DUPLICATE KEY UPDATE
       is_done = VALUES(is_done),
       meta_json = VALUES(meta_json),
       updated_by_role = VALUES(updated_by_role),
       updated_by_id = VALUES(updated_by_id),
       updated_at = NOW()`,
    [
      studentId,
      safePointName,
      stageKey,
      taskId,
      nextDone,
      JSON.stringify(mergedMeta),
      actorRole,
      actorId,
    ]
  )

  return {
    pointName: safePointName,
    taskId,
    stageKey,
    status: nextDone ? 'done' : 'pending',
    updatedAt: new Date().toISOString(),
  }
}

async function getDoneLearningPathTaskIds(studentId, pointName, stageKey) {
  const [rows] = await pool.query(
    `SELECT task_id
     FROM student_learning_path_tasks
     WHERE student_id = ? AND point_name = ? AND stage_key = ? AND is_done = 1`,
    [studentId, pointName, stageKey]
  )
  return new Set(rows.map((row) => row.task_id))
}

async function hasGradedSubmissionForFeedbackTask(studentId, pointName, stageKey, feedbackTaskId) {
  if (!studentId || !pointName || !stageKey || !feedbackTaskId) return false

  const uploadTaskId = getUploadTaskIdForFeedbackTask(feedbackTaskId)
  const params = [studentId, pointName, stageKey, feedbackTaskId]
  let taskCondition = ''

  if (uploadTaskId) {
    taskCondition = ' OR task_id = ?'
    params.push(uploadTaskId)
  }

  const [[row]] = await pool.query(
    `SELECT id
     FROM pdf_submissions
     WHERE student_id = ?
       AND point_name = ?
       AND stage_key = ?
       AND graded = 1
       AND (feedback_task_id = ?${taskCondition})
     ORDER BY graded_at DESC, created_at DESC
     LIMIT 1`,
    params
  )

  return !!row
}

async function validateStudentLearningPathPatch({
  studentId,
  pointName,
  stageKey,
  taskId,
  status,
  learningPathRows = [],
}) {
  if (status === 'pending' || status === 'current') {
    return null
  }

  if (isUploadTask(stageKey, taskId, learningPathRows)) {
    return '请通过上传入口提交 PDF，不能直接完成上传任务'
  }

  const doneTaskIds = await getDoneLearningPathTaskIds(studentId, pointName, stageKey)
  const missingPreviousTaskId = getPreviousTaskIds(stageKey, taskId, learningPathRows).find((previousTaskId) => !doneTaskIds.has(previousTaskId))
  if (missingPreviousTaskId) {
    return '请先按顺序完成前面的学习路径任务'
  }

  if (isFeedbackTask(stageKey, taskId, learningPathRows)) {
    const hasResult = await hasGradedSubmissionForFeedbackTask(studentId, pointName, stageKey, taskId)
    if (!hasResult) {
      return '老师还没有完成批改，暂时不能完成反馈任务'
    }
  }

  return null
}

function formatSubmission(row = {}) {
  const meta = readMeta(row.meta_json)

  return {
    id: row.id,
    studentId: row.student_id,
    studentName: row.student_name,
    reviewType: row.review_type,
    checkpoint: normalizeCheckpointName(row.checkpoint),
    deadline: row.deadline || '',
    priority: row.priority || 'normal',
    submittedNormal: Number(row.submitted_normal) === 1,
    fileName: row.file_name,
    pointName: row.point_name || normalizeCheckpointName(row.checkpoint),
    stageKey: row.stage_key || '',
    taskId: row.task_id || '',
    feedbackTaskId: row.feedback_task_id || '',
    graded: Number(row.graded) === 1,
    score: row.score,
    feedback: row.feedback || '',
    gradedAt: row.graded_at,
    reviewedFileName: row.reviewed_file_name || '',
    hasReviewedFile: !!row.reviewed_stored_file,
    submittedAt: row.created_at,
    meta,
  }
}

function normalizeCheckpointName(value) {
  const source = String(value || '').trim()
  if (!source) return ''

  return CHECKPOINT_NAME_ALIASES.reduce((result, [from, to]) => result.replaceAll(from, to), source)
}

function resolveReviewPointStatus(courseStatus = '') {
  const safeStatus = String(courseStatus || '').trim()

  if (safeStatus === 'completed') return 'completed'
  if (safeStatus === 'pending' || safeStatus === 'not_started') return 'pending'
  if (!safeStatus || safeStatus === 'failed' || safeStatus === 'aborted') return 'locked'

  return 'learning'
}

function applyReviewPointStatus(statusMap = {}, pointName = '', nextStatus = 'locked') {
  if (!pointName || !statusMap[pointName]) return

  const currentStatus = statusMap[pointName].status || 'locked'
  if ((REVIEW_POINT_STATUS_PRIORITY[nextStatus] || 99) < (REVIEW_POINT_STATUS_PRIORITY[currentStatus] || 99)) {
    statusMap[pointName].status = nextStatus
  }
}

async function getReviewPointStatuses(studentId) {
  const statusMap = REVIEW_POINT_LIST.reduce((result, item) => {
    result[item.pointName] = { ...item, status: 'locked' }
    return result
  }, {})

  const [courseRows] = await pool.query(
    `SELECT c.name AS pointName, sc.status
     FROM student_courses sc
     JOIN courses c ON c.id = sc.course_id
     WHERE sc.student_id = ?`,
    [studentId]
  )

  courseRows.forEach((row) => {
    applyReviewPointStatus(
      statusMap,
      normalizeCheckpointName(row.pointName),
      resolveReviewPointStatus(row.status)
    )
  })

  try {
    const [orderRows] = await pool.query(
      `SELECT DISTINCT c.name AS pointName
       FROM orders o
       JOIN order_items oi ON oi.order_id = o.id
       JOIN courses c ON c.id = oi.course_id
       WHERE o.student_id = ?
         AND o.status = 'paid'`,
      [studentId]
    )

    orderRows.forEach((row) => {
      applyReviewPointStatus(statusMap, normalizeCheckpointName(row.pointName), 'pending')
    })
  } catch (error) {
    if (!isMissingTableError(error)) {
      throw error
    }
  }

  return REVIEW_POINT_LIST.map((item) => statusMap[item.pointName])
}

async function buildStudentAccessSummary(studentId) {
  const [[studentCourseRow]] = await pool.query(
    `SELECT
       COUNT(*) AS totalCount,
       SUM(CASE WHEN status = 'completed' THEN 1 ELSE 0 END) AS completedCount,
       SUM(CASE WHEN status != 'completed' THEN 1 ELSE 0 END) AS activeCount
     FROM student_courses
     WHERE student_id = ?`,
    [studentId]
  )

  let paidOrderCourseCount = 0
  try {
    const [[paidOrderRow]] = await pool.query(
      `SELECT COUNT(*) AS count
       FROM orders o
       JOIN order_items oi ON oi.order_id = o.id
       WHERE o.student_id = ?
         AND o.status = 'paid'`,
      [studentId]
    )
    paidOrderCourseCount = Number(paidOrderRow && paidOrderRow.count) || 0
  } catch (error) {
    if (!isMissingTableError(error)) {
      throw error
    }
  }

  const [[diagnosisRow]] = await pool.query(
    `SELECT COUNT(*) AS count
     FROM diagnosis_reports
     WHERE student_id = ?`,
    [studentId]
  )

  let pointRateCount = 0
  try {
    const [[pointRateRow]] = await pool.query(
      `SELECT COUNT(*) AS count
       FROM review_point_scores
       WHERE student_id = ?`,
      [studentId]
    )
    pointRateCount = Number(pointRateRow && pointRateRow.count) || 0
  } catch (error) {
    if (!isMissingTableError(error)) {
      throw error
    }
  }

  const activeCourseCount = Number(studentCourseRow && studentCourseRow.activeCount) || 0
  const completedCourseCount = Number(studentCourseRow && studentCourseRow.completedCount) || 0
  const enrolledCourseCount = Number(studentCourseRow && studentCourseRow.totalCount) || 0
  const diagnosisReportCount = Number(diagnosisRow && diagnosisRow.count) || 0

  return {
    hasPurchasedCourse: enrolledCourseCount > 0 || paidOrderCourseCount > 0,
    hasDiagnoseCourse: diagnosisReportCount > 0 || pointRateCount > 0,
    activeCourseCount,
    completedCourseCount,
    enrolledCourseCount,
    paidOrderCourseCount,
    diagnosisReportCount,
    pointRateCount,
  }
}

function getStartOfDay(date = new Date()) {
  const current = new Date(date)
  current.setHours(0, 0, 0, 0)
  return current
}

function getStartOfWeek(date = new Date()) {
  const current = getStartOfDay(date)
  const day = current.getDay() || 7
  current.setDate(current.getDate() - day + 1)
  return current
}

function getStartOfMonth(date = new Date()) {
  const current = getStartOfDay(date)
  current.setDate(1)
  return current
}

function addDays(date, offset) {
  const current = new Date(date)
  current.setDate(current.getDate() + offset)
  return current
}

function addMonths(date, offset) {
  const current = new Date(date)
  current.setMonth(current.getMonth() + offset)
  return current
}

function formatDateKey(date) {
  const year = date.getFullYear()
  const month = `${date.getMonth() + 1}`.padStart(2, '0')
  const day = `${date.getDate()}`.padStart(2, '0')
  return `${year}-${month}-${day}`
}

function formatMonthKey(date) {
  const year = date.getFullYear()
  const month = `${date.getMonth() + 1}`.padStart(2, '0')
  return `${year}-${month}`
}

function buildDayBuckets(now = new Date(), count = 7) {
  const start = getStartOfWeek(now)
  const labels = ['\u5468\u4e00', '\u5468\u4e8c', '\u5468\u4e09', '\u5468\u56db', '\u5468\u4e94', '\u5468\u516d', '\u5468\u65e5']

  return Array.from({ length: count }, (_, index) => {
    const date = addDays(start, index)
    return {
      key: `day${index + 1}`,
      bucketKey: formatDateKey(date),
      label: labels[index] || `\u7b2c${index + 1}\u5929`,
      sortOrder: index + 1,
      cycleType: 'day',
    }
  })
}

function buildWeekBuckets(now = new Date(), count = 4) {
  const currentWeek = getStartOfWeek(now)

  return Array.from({ length: count }, (_, index) => {
    const date = addDays(currentWeek, (index - (count - 1)) * 7)
    return {
      key: `week${index + 1}`,
      bucketKey: formatDateKey(date),
      label: `\u7b2c${index + 1}\u5468`,
      sortOrder: index + 1,
      cycleType: 'week',
    }
  })
}

function buildMonthBuckets(now = new Date(), count = 6) {
  const currentMonth = getStartOfMonth(now)

  return Array.from({ length: count }, (_, index) => {
    const date = addMonths(currentMonth, index - (count - 1))
    return {
      key: `month${index + 1}`,
      bucketKey: formatMonthKey(date),
      label: `${date.getMonth() + 1}\u6708`,
      sortOrder: index + 1,
      cycleType: 'month',
    }
  })
}

async function buildStudyTimesFromSessions(studentId, now = new Date()) {
  const dayBuckets = buildDayBuckets(now)
  const weekBuckets = buildWeekBuckets(now)
  const monthBuckets = buildMonthBuckets(now)
  const allBuckets = [...dayBuckets, ...weekBuckets, ...monthBuckets]

  let sessionRows = []
  let manualRows = []
  try {
    const [rows] = await pool.query(
      `SELECT started_at, ended_at, duration_sec
       FROM study_sessions
       WHERE student_id = ?
         AND started_at IS NOT NULL
         AND status IN ('started', 'completed')`,
      [studentId]
    )
    sessionRows = rows
  } catch (error) {
    if (!isMissingTableError(error)) {
      throw error
    }
  }

  try {
    const [rows] = await pool.query(
      `SELECT
         period_key AS \`key\`,
         period_label AS label,
         hours,
         sort_order AS sortOrder,
         cycle_type AS cycleType
       FROM study_time_stats
       WHERE student_id = ?
         AND id IN (
           SELECT MAX(id)
           FROM study_time_stats
           WHERE student_id = ?
           GROUP BY period_key
         )
       ORDER BY sort_order ASC, id ASC`,
      [studentId, studentId]
    )
    manualRows = rows
  } catch (error) {
    if (!isMissingTableError(error)) {
      throw error
    }
  }

  const sessionTotals = {
    day: {},
    week: {},
    month: {},
  }

  sessionRows.forEach((row) => {
    const startedAt = row.started_at ? new Date(row.started_at) : null
    if (!startedAt || Number.isNaN(startedAt.getTime())) return

    const rawDuration = Number(row.duration_sec || 0)
    const endedAt = row.ended_at ? new Date(row.ended_at) : null
    const durationSec = rawDuration > 0
      ? rawDuration
      : endedAt && !Number.isNaN(endedAt.getTime())
        ? Math.max(0, Math.round((endedAt.getTime() - startedAt.getTime()) / 1000))
        : 0
    const hours = Math.round((durationSec / 3600) * 100) / 100
    if (hours <= 0) return

    const dayKey = formatDateKey(startedAt)
    const weekKey = formatDateKey(getStartOfWeek(startedAt))
    const monthKey = formatMonthKey(startedAt)
    sessionTotals.day[dayKey] = (sessionTotals.day[dayKey] || 0) + hours
    sessionTotals.week[weekKey] = (sessionTotals.week[weekKey] || 0) + hours
    sessionTotals.month[monthKey] = (sessionTotals.month[monthKey] || 0) + hours
  })

  const manualRowsByKey = new Map(
    manualRows
      .map((row) => {
        const key = String(row.key || '').trim()
        const cycleType = ['day', 'week', 'month'].includes(row.cycleType) ? row.cycleType : 'week'
        const sortOrder = Number(row.sortOrder || 0)
        const hours = Number(row.hours)
        if (!key || !Number.isFinite(hours)) {
          return null
        }

        return [
          key,
          {
            key,
            label: String(row.label || '').trim() || key,
            hours: Math.max(0, Math.round(hours * 100) / 100),
            sortOrder,
            cycleType,
          },
        ]
      })
      .filter(Boolean)
  )

  const bucketKeySet = new Set(allBuckets.map((bucket) => bucket.key))
  const mergedRows = allBuckets.map((bucket) => {
    const manualRow = manualRowsByKey.get(bucket.key)
    const sessionHours = sessionTotals[bucket.cycleType][bucket.bucketKey] || 0
    const manualHours = manualRow ? manualRow.hours : 0

    return {
      key: bucket.key,
      label: manualRow && manualRow.label ? manualRow.label : bucket.label,
      hours: Math.round((sessionHours + manualHours) * 100) / 100,
      sortOrder: bucket.sortOrder,
      cycleType: bucket.cycleType,
    }
  })

  const extraManualRows = [...manualRowsByKey.values()]
    .filter((row) => !bucketKeySet.has(row.key))
    .sort((left, right) => {
      if (left.cycleType !== right.cycleType) {
        return `${left.cycleType}`.localeCompare(`${right.cycleType}`)
      }
      return Number(left.sortOrder || 0) - Number(right.sortOrder || 0)
    })

  return [...mergedRows, ...extraManualRows]
}

function resolveSessionDurationSec(payload = {}) {
  const directDuration = Number(payload.durationSec)
  if (Number.isFinite(directDuration) && directDuration >= 0) {
    return Math.round(directDuration)
  }

  const startedAt = payload.startedAt ? new Date(payload.startedAt) : null
  const endedAt = payload.endedAt ? new Date(payload.endedAt) : null
  if (startedAt && endedAt && !Number.isNaN(startedAt.getTime()) && !Number.isNaN(endedAt.getTime())) {
    return Math.max(0, Math.round((endedAt.getTime() - startedAt.getTime()) / 1000))
  }

  return 0
}

async function resolvePrescribedDurationSec(studentId, studyTaskId, durationMin) {
  const safeDurationMin = Number(durationMin)

  if (studyTaskId) {
    const [[taskRow]] = await pool.query(
      `SELECT st.duration_min AS durationMin
       FROM study_tasks st
       JOIN study_days sd ON sd.id = st.study_day_id
       WHERE st.id = ?
         AND sd.student_id = ?
       LIMIT 1`,
      [studyTaskId, studentId]
    )

    const taskDurationMin = Number(taskRow && taskRow.durationMin)
    if (Number.isFinite(taskDurationMin) && taskDurationMin > 0) {
      return Math.round(taskDurationMin * 60)
    }
  }

  if (Number.isFinite(safeDurationMin) && safeDurationMin > 0) {
    return Math.round(safeDurationMin * 60)
  }

  return 0
}

function toValidDate(value) {
  const date = value instanceof Date ? value : new Date(value)
  return Number.isNaN(date.getTime()) ? null : date
}

function toIsoString(value) {
  const date = toValidDate(value)
  return date ? date.toISOString() : ''
}

function getLocalDayKey(date) {
  return formatDateKey(getStartOfDay(date))
}

function getLateScore(date) {
  const hours = date.getHours() + (date.getMinutes() / 60)
  return hours < 5 ? hours + 24 : hours
}

router.get('/point-learning-summary', async (req, res) => {
  const studentId = req.user.id
  const pointName = String(req.query.pointName || '').trim()

  if (!pointName) {
    return res.status(400).json({ message: '缺少卡点名称' })
  }

  try {
    const [[pointRow]] = await pool.query(
      `SELECT drp.course_id
       FROM diagnosis_report_points drp
       JOIN diagnosis_reports dr ON dr.id = drp.report_id
       WHERE dr.student_id = ?
         AND drp.point_name = ?
       ORDER BY COALESCE(dr.diagnosis_date, dr.created_at) DESC, dr.id DESC, drp.sort_order ASC
       LIMIT 1`,
      [studentId, pointName]
    )

    const courseId = pointRow && pointRow.course_id ? Number(pointRow.course_id) : null
    const querySql = courseId
      ? `SELECT started_at, ended_at, duration_sec
         FROM study_sessions
         WHERE student_id = ?
           AND (course_id = ? OR point_name = ?)
           AND started_at IS NOT NULL
           AND status IN ('started', 'completed')`
      : `SELECT started_at, ended_at, duration_sec
         FROM study_sessions
         WHERE student_id = ?
           AND point_name = ?
           AND started_at IS NOT NULL
           AND status IN ('started', 'completed')`
    const queryParams = courseId ? [studentId, courseId, pointName] : [studentId, pointName]
    const [rows] = await pool.query(querySql, queryParams)

    let totalDurationSec = 0
    let earliestSession = null
    let latestSession = null
    const dayTotals = new Map()

    rows.forEach((row) => {
      const startedAt = toValidDate(row.started_at)
      if (!startedAt) return

      const endedAt = toValidDate(row.ended_at)
      const rawDuration = Number(row.duration_sec || 0)
      const durationSec = rawDuration > 0
        ? rawDuration
        : endedAt
          ? Math.max(0, Math.round((endedAt.getTime() - startedAt.getTime()) / 1000))
          : 0

      if (durationSec <= 0) return

      totalDurationSec += durationSec

      const dayKey = getLocalDayKey(startedAt)
      const currentDay = dayTotals.get(dayKey) || { date: dayKey, durationSec: 0 }
      currentDay.durationSec += durationSec
      dayTotals.set(dayKey, currentDay)

      const startClock = startedAt.getHours() * 60 + startedAt.getMinutes()
      if (!earliestSession || startClock < earliestSession.clock) {
        earliestSession = {
          date: dayKey,
          startedAt: toIsoString(startedAt),
          clock: startClock,
        }
      }

      const sessionEnd = endedAt || new Date(startedAt.getTime() + durationSec * 1000)
      const lateScore = getLateScore(sessionEnd)
      if (!latestSession || lateScore > latestSession.score) {
        latestSession = {
          date: dayKey,
          endedAt: toIsoString(sessionEnd),
          score: lateScore,
        }
      }
    })

    const longestDay = [...dayTotals.values()]
      .sort((left, right) => {
        if (right.durationSec !== left.durationSec) {
          return right.durationSec - left.durationSec
        }
        return `${right.date}`.localeCompare(`${left.date}`)
      })[0] || null

    res.json({
      pointName,
      courseId,
      totalDurationSec,
      longestDay: longestDay
        ? {
            date: longestDay.date,
            durationSec: longestDay.durationSec,
          }
        : null,
      earliestSession: earliestSession
        ? {
            date: earliestSession.date,
            startedAt: earliestSession.startedAt,
          }
        : null,
      latestSession: latestSession
        ? {
            date: latestSession.date,
            endedAt: latestSession.endedAt,
          }
        : null,
    })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.get('/learning-path', async (req, res) => {
  const studentId = req.user.id
  const pointName = String(req.query.pointName || req.body?.pointName || '').trim()

  if (!pointName) {
    return res.status(400).json({ message: '缺少卡点名称' })
  }

  try {
    res.json(await buildStudentLearningPath(studentId, pointName))
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.patch('/learning-path/tasks/:taskId', async (req, res) => {
  const studentId = req.user.id
  const taskId = String(req.params.taskId || '').trim()
  const pointName = String(req.body.pointName || '').trim()
  const stageKey = String(req.body.stageKey || '').trim()

  if (!taskId) {
    return res.status(400).json({ message: '任务 ID 无效' })
  }

  if (!pointName) {
    return res.status(400).json({ message: '缺少卡点名称' })
  }

  if (!stageKey) {
    return res.status(400).json({ message: '缺少阶段标识' })
  }

  const status = String(req.body.status || 'done').trim() || 'done'
  const metaPatch = {
    selectedLabel: req.body.selectedLabel,
    uploadCount: req.body.uploadCount,
    uploadedAt: req.body.uploadedAt,
    processingStartedAt: req.body.processingStartedAt,
    processingDone: req.body.processingDone,
    timerSeconds: req.body.timerSeconds,
    timerFinishedAt: req.body.timerFinishedAt,
    appointment: req.body.appointment,
    rating: req.body.rating,
    result: req.body.result,
    resource: req.body.resource,
    uploads: req.body.uploads,
  }

  try {
    const safePointName = normalizeCheckpointName(pointName)
    const learningPathRows = await loadLearningPathRows(studentId, safePointName)
    const taskDefinition = findTaskDefinition(stageKey, taskId, learningPathRows)
    if (!taskDefinition) {
      return res.status(400).json({ message: '学习路径任务不存在' })
    }

    const validationError = await validateStudentLearningPathPatch({
      studentId,
      pointName: safePointName,
      stageKey,
      taskId,
      status,
      learningPathRows,
    })

    if (validationError) {
      return res.status(400).json({ message: validationError })
    }

    const payload = await saveLearningPathTask({
      studentId,
      pointName,
      stageKey,
      taskId,
      status,
      metaPatch,
      actorRole: 'student',
      actorId: studentId,
    })
    res.json({ ok: true, ...payload })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.get('/submissions', async (req, res) => {
  const studentId = req.user.id
  const pointName = normalizeCheckpointName(req.query.pointName || '')
  const stageKey = String(req.query.stageKey || '').trim()
  const taskId = String(req.query.taskId || '').trim()
  const feedbackTaskId = String(req.query.feedbackTaskId || '').trim()
  const graded = String(req.query.graded || '').trim()

  const where = ['student_id = ?']
  const params = [studentId]

  if (pointName) {
    where.push('point_name = ?')
    params.push(pointName)
  }

  if (stageKey) {
    where.push('stage_key = ?')
    params.push(stageKey)
  }

  if (taskId) {
    where.push('(task_id = ? OR feedback_task_id = ?)')
    params.push(taskId, taskId)
  }

  if (feedbackTaskId) {
    where.push('feedback_task_id = ?')
    params.push(feedbackTaskId)
  }

  if (graded === 'true' || graded === '1') {
    where.push('graded = 1')
  } else if (graded === 'false' || graded === '0') {
    where.push('graded = 0')
  }

  try {
    const [rows] = await pool.query(
      `SELECT id, student_id, student_name, review_type, checkpoint, deadline, priority,
              submitted_normal, file_name, point_name, stage_key, task_id, feedback_task_id,
              reviewed_file_name, reviewed_stored_file,
              graded, score, feedback, graded_at, created_at
       FROM pdf_submissions
       WHERE ${where.join(' AND ')}
       ORDER BY created_at DESC, id DESC`,
      params
    )

    res.json(rows.map(formatSubmission))
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.get('/submissions/:submissionId', async (req, res) => {
  const studentId = req.user.id
  const submissionId = String(req.params.submissionId || '').trim()

  if (!submissionId) {
    return res.status(400).json({ message: '提交记录 ID 无效' })
  }

  try {
    const [[row]] = await pool.query(
      `SELECT id, student_id, student_name, review_type, checkpoint, deadline, priority,
              submitted_normal, file_name, point_name, stage_key, task_id, feedback_task_id,
              reviewed_file_name, reviewed_stored_file,
              graded, score, feedback, graded_at, created_at
       FROM pdf_submissions
       WHERE id = ? AND student_id = ?
       LIMIT 1`,
      [submissionId, studentId]
    )

    if (!row) {
      return res.status(404).json({ message: '提交记录不存在' })
    }

    res.json(formatSubmission(row))
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.get('/submissions/:submissionId/review-file', async (req, res) => {
  const studentId = req.user.id
  const submissionId = String(req.params.submissionId || '').trim()

  if (!submissionId) {
    return res.status(400).json({ message: '提交记录 ID 无效' })
  }

  try {
    const [[row]] = await pool.query(
      `SELECT reviewed_file_name, reviewed_stored_file
       FROM pdf_submissions
       WHERE id = ? AND student_id = ?
       LIMIT 1`,
      [submissionId, studentId]
    )

    if (!row) {
      return res.status(404).json({ message: '提交记录不存在' })
    }

    if (!row.reviewed_stored_file) {
      return res.status(404).json({ message: '老师暂未上传批改 PDF' })
    }

    const filePath = path.join(UPLOADS_DIR, row.reviewed_stored_file)
    if (!fs.existsSync(filePath)) {
      return res.status(404).json({ message: '批改 PDF 文件不存在' })
    }

    res.setHeader('Content-Type', 'application/pdf')
    res.setHeader('Content-Disposition', `inline; filename="${encodeURIComponent(row.reviewed_file_name || 'reviewed.pdf')}"`)
    fs.createReadStream(filePath).pipe(res)
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})


router.get('/profile', async (req, res) => {
  const studentId = req.user.id

  try {
    const [inProgress] = await pool.query(
      `SELECT sc.id, sc.course_id AS course_id, c.name, c.subject, sc.progress, sc.status
       FROM student_courses sc
       JOIN courses c ON sc.course_id = c.id
       WHERE sc.student_id = ? AND sc.status != 'completed'`,
      [studentId]
    )

    const [completed] = await pool.query(
      `SELECT sc.id, sc.course_id AS course_id, c.name, c.subject, sc.progress, sc.status
       FROM student_courses sc
       JOIN courses c ON sc.course_id = c.id
       WHERE sc.student_id = ? AND sc.status = 'completed'`,
      [studentId]
    )

    res.json({ inProgress, completed })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.get('/access-summary', async (req, res) => {
  try {
    res.json(await buildStudentAccessSummary(req.user.id))
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.get('/study/:courseId', async (req, res) => {
  const { courseId } = req.params
  const studentId = req.user.id

  try {
    const [[course]] = await pool.query(
      `SELECT sc.progress, sc.status, c.name
       FROM student_courses sc
       JOIN courses c ON sc.course_id = c.id
       WHERE sc.student_id = ? AND sc.course_id = ?`,
      [studentId, courseId]
    )

    if (!course) {
      return res.status(404).json({ message: '未找到课程' })
    }

    const [days] = await pool.query(
      'SELECT * FROM study_days WHERE student_id = ? AND course_id = ? ORDER BY day_number',
      [studentId, courseId]
    )

    for (const day of days) {
      const [tasks] = await pool.query(
        'SELECT * FROM study_tasks WHERE study_day_id = ? ORDER BY sort_order',
        [day.id]
      )
      for (const task of tasks) {
        const [resources] = await pool.query(
          `SELECT id, resource_type, phase, title, url, video_id, sort_order
           FROM task_resources
           WHERE task_id = ?
           ORDER BY sort_order, id`,
          [task.id]
        )
        task.resources = resources
      }
      day.tasks = tasks
    }

    res.json({ course, days })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.put('/study/tasks/:taskId/complete', async (req, res) => {
  try {
    await pool.query('UPDATE study_tasks SET completed = 1 WHERE id = ?', [req.params.taskId])
    res.json({ message: '已完成' })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.get('/review', async (req, res) => {
  const studentId = req.user.id

  try {
    const [reviews] = await pool.query(
      'SELECT * FROM reviews WHERE student_id = ? ORDER BY created_at DESC LIMIT 1',
      [studentId]
    )
    const review = reviews[0]

    if (!review) {
      return res.json(null)
    }

    const [items] = await pool.query(
      'SELECT * FROM review_items WHERE review_id = ? ORDER BY type, sort_order',
      [review.id]
    )

    res.json({ ...review, items })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.get('/review-overview', async (req, res) => {
  const studentId = req.user.id

  try {
    const [[firstDiagnosis]] = await pool.query(
      `SELECT id, target_exam AS targetExam, diagnosis_score, target_score, diagnosis_date, created_at
       FROM diagnosis_reports
       WHERE student_id = ?
       ORDER BY COALESCE(diagnosis_date, created_at) ASC, id ASC
       LIMIT 1`,
      [studentId]
    )

    const [[latestDiagnosis]] = await pool.query(
      `SELECT id, target_exam AS targetExam, diagnosis_score, target_score, diagnosis_date, created_at
       FROM diagnosis_reports
       WHERE student_id = ?
       ORDER BY COALESCE(diagnosis_date, created_at) DESC, id DESC
       LIMIT 1`,
      [studentId]
    )

    let pointRates = []
    try {
      const [rows] = await pool.query(
        `SELECT
           point_name AS pointName,
           current_rate AS currentRate,
           target_rate AS targetRate,
           sort_order AS sortOrder,
           source_type AS sourceType,
           created_at AS updatedAt
         FROM review_point_scores
         WHERE student_id = ?
           AND id IN (
             SELECT MAX(id)
             FROM review_point_scores
             WHERE student_id = ?
             GROUP BY point_name
           )
         ORDER BY sort_order ASC, id ASC`,
        [studentId, studentId]
      )
      pointRates = rows
    } catch (error) {
      if (!isMissingTableError(error)) {
        throw error
      }
    }

    const studyTimes = await buildStudyTimesFromSessions(studentId)
    const pointStatuses = await getReviewPointStatuses(studentId)

    res.json({
      targetExam: latestDiagnosis && latestDiagnosis.targetExam
        ? latestDiagnosis.targetExam
        : firstDiagnosis && firstDiagnosis.targetExam
          ? firstDiagnosis.targetExam
          : '',
      progress: {
        entryScore: firstDiagnosis ? firstDiagnosis.diagnosis_score : null,
        currentScore: latestDiagnosis && firstDiagnosis && latestDiagnosis.id !== firstDiagnosis.id
          ? latestDiagnosis.diagnosis_score
          : null,
        targetScore: latestDiagnosis
          ? latestDiagnosis.target_score
          : firstDiagnosis
            ? firstDiagnosis.target_score
            : null,
      },
      pointRates,
      pointStatuses,
      studyTimes,
    })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.post('/study-sessions', async (req, res) => {
  const studentId = req.user.id
  const {
    courseId = null,
    studyTaskId = null,
    pointName = '',
    sessionType = 'other',
    status = 'completed',
    startedAt,
    endedAt,
    durationSec,
    durationMin = null,
    prescribed = false,
  } = req.body || {}

  const allowedSessionTypes = new Set(['lesson', 'video', 'practice', 'review', 'exam', 'other'])
  const allowedStatuses = new Set(['started', 'completed', 'aborted'])
  const safeSessionType = allowedSessionTypes.has(sessionType) ? sessionType : 'other'
  const safeStatus = allowedStatuses.has(status) ? status : 'completed'
  const safeStartedAt = startedAt ? new Date(startedAt) : new Date()
  const safeEndedAt = endedAt ? new Date(endedAt) : new Date()

  if (Number.isNaN(safeStartedAt.getTime())) {
    return res.status(400).json({ message: '开始时间无效' })
  }

  try {
    const resolvedDurationSec = prescribed
      ? await resolvePrescribedDurationSec(studentId, studyTaskId, durationMin)
      : resolveSessionDurationSec({
          durationSec,
          startedAt: safeStartedAt,
          endedAt: safeEndedAt,
        })

    if (prescribed && resolvedDurationSec <= 0) {
      return res.status(400).json({ message: '未找到规定时长' })
    }

    const [result] = await pool.query(
      `INSERT INTO study_sessions (student_id, course_id, study_task_id, point_name, session_type, status, started_at, ended_at, duration_sec)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [
        studentId,
        courseId || null,
        studyTaskId || null,
        String(pointName || '').trim() || null,
        safeSessionType,
        safeStatus,
        safeStartedAt,
        safeStatus === 'started' ? null : (Number.isNaN(safeEndedAt.getTime()) ? null : safeEndedAt),
        resolvedDurationSec,
      ]
    )

    res.json({
      id: result.insertId,
      message: '学习记录已保存',
    })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.get('/outline/:courseId', async (req, res) => {
  const { courseId } = req.params
  const studentId = req.user.id

  try {
    const [outlineItems] = await pool.query(
      'SELECT * FROM outline_items WHERE student_id = ? AND course_id = ? ORDER BY type, sort_order',
      [studentId, courseId]
    )
    res.json({ outlineItems })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.get('/courses', async (_req, res) => {
  try {
    const [courses] = await pool.query('SELECT * FROM courses WHERE is_active = 1')
    res.json(courses)
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

function notificationUrlByType(type, relatedType, relatedId) {
  if (type === 'class') return '/pages/lesson-live/lesson-live'
  if (type === 'exam') return '/pages/lesson-exam/lesson-exam'
  if (type === 'homework') return '/pages/lesson-correct/lesson-correct'
  if (type === 'review') return '/pages/results/results'
  if (type === 'leave') return '/pages/leave/leave'
  if (relatedType === 'diagnose_detail') return '/pages/diagnose-detail/diagnose-detail?source=notification'
  if (relatedType === 'diagnose_coupon') return '/pages/purchase/purchase?mode=diagnose&coupon=1&source=notification'
  if (relatedType === 'submission' && relatedId) return '/pages/results/results'
  return '/pages/notifications/notifications'
}

function formatNotification(row) {
  return {
    id: String(row.id),
    type: row.type,
    title: row.title,
    content: row.content || '',
    relatedType: row.related_type || '',
    relatedId: row.related_id || '',
    scheduledAt: row.scheduled_at,
    createdAt: row.created_at,
    isRead: Boolean(row.is_read),
    url: notificationUrlByType(row.type, row.related_type, row.related_id),
  }
}

router.get('/notifications', async (req, res) => {
  const studentId = req.user.id

  try {
    const [rows] = await pool.query(
      `SELECT id, type, title, content, related_type, related_id, scheduled_at, is_read, read_at, created_at
       FROM notifications
       WHERE student_id = ?
       ORDER BY COALESCE(scheduled_at, created_at) DESC, id DESC
       LIMIT 50`,
      [studentId]
    )

    res.json(rows.map(formatNotification))
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.patch('/notifications/read-all', async (req, res) => {
  const studentId = req.user.id

  try {
    await pool.query(
      'UPDATE notifications SET is_read = 1, read_at = NOW() WHERE student_id = ? AND is_read = 0',
      [studentId]
    )
    res.json({ message: '已全部已读' })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.patch('/notifications/:id/read', async (req, res) => {
  const studentId = req.user.id

  try {
    await pool.query(
      'UPDATE notifications SET is_read = 1, read_at = NOW() WHERE id = ? AND student_id = ?',
      [req.params.id, studentId]
    )
    res.json({ message: '已读' })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.post('/feedbacks', async (req, res) => {
  const studentId = req.user.id
  const source = sanitizeFeedbackSource(req.body.source)
  const title = String(req.body.title || '').trim().slice(0, 120)
  const pointName = normalizeCheckpointName(String(req.body.pointName || '').trim()).slice(0, 100)
  const content = String(req.body.content || '').trim().slice(0, 5000)
  const attachmentsInput = Array.isArray(req.body.attachments) ? req.body.attachments : []
  const rawCourseId = Number(req.body.courseId)
  const courseId = Number.isFinite(rawCourseId) && rawCourseId > 0 ? rawCourseId : null
  const rawMeta = req.body.meta && typeof req.body.meta === 'object' && !Array.isArray(req.body.meta)
    ? req.body.meta
    : {}
  const meta = {
    videoTitle: String(rawMeta.videoTitle || '').trim().slice(0, 120),
    recordedDoneCount: Math.max(0, Number(rawMeta.recordedDoneCount) || 0),
    recordedTasksTotal: Math.max(0, Number(rawMeta.recordedTasksTotal) || 0),
  }

  if (!source) {
    return res.status(400).json({ message: '反馈来源无效' })
  }

  if (!content && attachmentsInput.length === 0) {
    return res.status(400).json({ message: '请填写反馈内容或上传图片' })
  }

  if (attachmentsInput.length > 6) {
    return res.status(400).json({ message: '最多上传 6 张图片' })
  }

  try {
    await ensureStudentFeedbackTable()

    const attachments = await persistFeedbackAttachments(attachmentsInput, UPLOADS_DIR)
    const [result] = await pool.query(
      `INSERT INTO student_feedback_messages (
         student_id, source, title, point_name, course_id, content,
         attachments_json, meta_json, status
       ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'pending')`,
      [
        studentId,
        source,
        title || null,
        pointName || null,
        courseId,
        content || null,
        JSON.stringify(attachments),
        JSON.stringify(meta),
      ],
    )

    res.json({
      id: result.insertId,
      status: 'pending',
      message: '反馈已提交',
    })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.post('/mailbox', async (req, res) => {
  const studentId = req.user.id
  const category = String(req.body.category || '教学建议').trim().slice(0, 50) || '教学建议'
  const content = String(req.body.content || '').trim()
  const anonymous = req.body.anonymous === undefined ? true : Boolean(req.body.anonymous)

  if (!content) {
    return res.status(400).json({ message: '请填写内容' })
  }

  try {
    const [result] = await pool.query(
      `INSERT INTO student_mailbox_messages (student_id, category, content, anonymous, status)
       VALUES (?, ?, ?, ?, 'pending')`,
      [studentId, category, content, anonymous ? 1 : 0]
    )

    await pool.query(
      `INSERT INTO notifications (student_id, type, title, content, related_type, related_id, scheduled_at)
       VALUES (?, 'system', ?, ?, 'mailbox', ?, NOW())`,
      [
        studentId,
        '校长信箱已投递',
        '你的反馈已收到，我们会尽快查看并跟进。',
        String(result.insertId),
      ]
    )

    res.json({
      id: result.insertId,
      status: 'pending',
      message: '提交成功',
    })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.post('/leave', async (req, res) => {
  const studentId = req.user.id
  const { type, courseId, pointName, stepName, days, reason } = req.body

  try {
    if (courseId) {
      const [[leaveCount]] = await pool.query(
        `SELECT COUNT(*) as count FROM leave_requests
         WHERE student_id = ? AND course_id = ? AND status != 'rejected'`,
        [studentId, courseId]
      )

      if (leaveCount.count >= 2) {
        return res.status(400).json({ message: '该卡点请假次数已达上限（2次）' })
      }
    }

    const [result] = await pool.query(
      `INSERT INTO leave_requests (student_id, type, course_id, point_name, step_name, days, reason)
       VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [studentId, type || 'single', courseId || null, pointName || '', stepName || '', days || 1, reason || '']
    )

    await pool.query(
      `INSERT INTO notifications (student_id, type, title, content, related_type, related_id, scheduled_at)
       VALUES (?, 'leave', ?, ?, 'leave_request', ?, NOW())`,
      [
        studentId,
        '请假申请已提交',
        `你的请假申请已提交，等待老师审批。${pointName ? `卡点：${pointName}` : ''}`,
        String(result.insertId),
      ]
    )

    res.json({ id: result.insertId, status: 'pending', message: '请假申请已提交' })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.get('/leave', async (req, res) => {
  const studentId = req.user.id

  try {
    const [rows] = await pool.query(
      'SELECT * FROM leave_requests WHERE student_id = ? ORDER BY created_at DESC',
      [studentId]
    )
    res.json(rows)
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.patch('/leave/:id/approve', async (req, res) => {
  try {
    await pool.query(
      "UPDATE leave_requests SET status = 'approved', approved_at = NOW() WHERE id = ?",
      [req.params.id]
    )
    res.json({ message: '已审批' })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

router.delete('/leave/:id', async (req, res) => {
  const studentId = req.user.id

  try {
    const [result] = await pool.query(
      "DELETE FROM leave_requests WHERE id = ? AND student_id = ? AND status = 'pending'",
      [req.params.id, studentId]
    )

    if (result.affectedRows === 0) {
      return res.status(400).json({ message: '申请不存在或已审批，无法取消' })
    }

    res.json({ message: '已取消' })
  } catch (err) {
    res.status(500).json({ message: err.message })
  }
})

module.exports = router
