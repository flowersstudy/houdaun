﻿const fs = require('fs')
const path = require('path')
const { execFileSync } = require('child_process')
const mysql = require('mysql2/promise')
const bcrypt = require('bcryptjs')
const { getDbConfig } = require('../config/env')

const UPLOADS_DIR = path.join(__dirname, '../../uploads')
const SAMPLE_PDF_NAME = 'sample-seed.pdf'
const SAMPLE_PDF_PATH = path.join(UPLOADS_DIR, SAMPLE_PDF_NAME)
const PRIMARY_TEACHER_KEY = 'li'
const DAY_MS = 24 * 60 * 60 * 1000

function dateOffset(days) {
  const value = new Date(Date.now() + days * DAY_MS)
  const yyyy = value.getFullYear()
  const mm = String(value.getMonth() + 1).padStart(2, '0')
  const dd = String(value.getDate()).padStart(2, '0')
  return `${yyyy}-${mm}-${dd}`
}

function dateTimeOffset(days, time) {
  return `${dateOffset(days)} ${time}`
}

function buildDefaultReviewPointScores(student = {}) {
  const diagnosisPoints = student && student.diagnosis && Array.isArray(student.diagnosis.points)
    ? student.diagnosis.points
    : []

  return diagnosisPoints.map((point, index) => ({
    point_name: point.point_name,
    current_rate: Math.max(45, 62 - index * 6),
    target_rate: Math.max(70, 82 - index * 4),
    source_type: index === 0 ? 'monthly_review' : 'diagnosis',
    sort_order: index + 1,
  }))
}

function buildDefaultStudyTimeStats() {
  return [
    { period_key: 'week1', period_label: '绗竴鍛?, hours: 30, cycle_type: 'week', sort_order: 1 },
    { period_key: 'week2', period_label: '绗簩鍛?, hours: 20, cycle_type: 'week', sort_order: 2 },
    { period_key: 'week3', period_label: '绗笁鍛?, hours: 10, cycle_type: 'week', sort_order: 3 },
    { period_key: 'week4', period_label: '绗洓鍛?, hours: 45, cycle_type: 'week', sort_order: 4 },
  ]
}

const teachers = [
  { key: 'li', name: '鏉庤€佸笀', email: 'li@test.com', title: '甯︽暀鑰佸笀' },
  { key: 'wang', name: '鐜嬭€佸笀', email: 'wang@test.com', title: '璇婃柇鑰佸笀' },
  { key: 'chen', name: '闄堣€佸笀', email: 'chen@test.com', title: '鏁欏姟鑰佸笀' },
  { key: 'lin', name: '鏋楄€佸笀', email: 'lin@test.com', title: '鍔╂暀鑰佸笀' },
  { key: 'liu', name: '鍒樿€佸笀', email: 'liu@test.com', title: '鏍￠暱鑰佸笀' },
]

const courseCatalog = [
  { name: '??????', subject: '??', description: '????????????????', price: 1080 },
  { name: '??????', subject: '??', description: '????????????????', price: 1080 },
  { name: '??????', subject: '??', description: '????????????????', price: 1080 },
  { name: '??????', subject: '??', description: '????????????????', price: 1080 },
  { name: '??????', subject: '??', description: '????????????????', price: 1080 },
  { name: '??????', subject: '??', description: '????????????????', price: 1080 },
  { name: '??????', subject: '??', description: '????????????????', price: 1080 },
  { name: '??????', subject: '??', description: '????????????????', price: 1080 },
]
const courseStudyBlueprints = {
  瑕佺偣涓嶅叏涓嶅噯: [
    {
      day: 1,
      status: 'completed',
      tasks: [{
        name: '[蹇呭] 鐢宠鍚勪綔绛旇绱犺瘑鍒笌涔﹀啓',
        description: '鐞嗚璇撅細鎵剧偣涓嶅叏闈紙鐞嗚鏂规硶璁茶В锛夛綔瀛﹀憳鍩虹锛氭爣鍑嗭綔閫傜敤鐪佷唤锛氭墍鏈夌渷浠斤綔璧勬簮鐘舵€侊細宸叉湁',
        type: 'video',
        duration: 45,
        completed: 1,
        resources: [
          {
            resource_type: 'pdf',
            phase: 'pre',
            title: '璇惧墠浣滀笟锛氭壘鐐逛笉鍏ㄩ潰锛堢悊璁烘柟娉曡瑙ｏ級',
            url: 'http://img.yaotia.com/2025/04-18/1744978559304.pdf',
            video_id: null,
          },
          {
            resource_type: 'video',
            phase: 'main',
            title: '褰曟挱璇撅細鎵剧偣涓嶅叏闈紙鐞嗚鏂规硶璁茶В锛?,
            url: null,
            video_id: '1e6eaa05af3e219ececff428b834bfec_1',
          },
        ],
      }],
    },
    {
      day: 2,
      status: 'completed',
      tasks: [{
        name: '[蹇呭] 鐢宠鍚勪綔绛旇绱犺瘑鍒笌涔﹀啓 路 浣滀笟璁茶В',
        description: '鐞嗚璇撅細鎵剧偣涓嶅叏闈紙浣滀笟璁茶В璇撅級锝滃鍛樺熀纭€锛氭爣鍑嗭綔閫傜敤鐪佷唤锛氭墍鏈夌渷浠斤綔璧勬簮鐘舵€侊細宸叉湁',
        type: 'review',
        duration: 35,
        completed: 1,
        resources: [
          {
            resource_type: 'pdf',
            phase: 'pre',
            title: '璇惧墠浣滀笟锛氭壘鐐逛笉鍏ㄩ潰锛堜綔涓氳瑙ｈ锛?,
            url: 'http://img.yaotia.com/2025/04-17/1744880978056.pdf',
            video_id: null,
          },
          {
            resource_type: 'video',
            phase: 'main',
            title: '褰曟挱璇撅細鎵剧偣涓嶅叏闈紙浣滀笟璁茶В璇撅級',
            url: null,
            video_id: '1e6eaa05af16261b021b9dafbaf9214c_1',
          },
          {
            resource_type: 'pdf',
            phase: 'post',
            title: '浣滀笟瑙ｆ瀽锛氭壘鐐逛笉鍏ㄩ潰锛堜綔涓氳瑙ｈ锛?,
            url: 'http://img.yaotia.com/2025/04-27/1745725412821.pdf',
            video_id: null,
          },
        ],
      }],
    },
    {
      day: 3,
      status: 'in_progress',
      tasks: [{
        name: '[閫夊] 鈥滄纭殑鐢宠闃呰瑙勫垯鎰忚瘑鈥?,
        description: '鐞嗚璇撅細銆愬熀纭€鐗堛€戞帉鎻℃纭殑闃呰璁ょ煡銆愯鐐圭殑鏋勬垚銆佽瘎鍒嗘爣鍑嗐€侀槄璇讳範鎯€戯綔瀛﹀憳鍩虹锛氳ˉ寮憋綔閫傜敤鐪佷唤锛氭墍鏈夌渷浠斤綔璧勬簮鐘舵€侊細寰呰ˉ鍏?,
        type: 'video',
        duration: 25,
        completed: 0,
        resources: [],
      }],
    },
    {
      day: 4,
      status: 'pending',
      tasks: [{
        name: '[閫夊] 鈥滄纭殑鐢宠闃呰瑙勫垯鎰忚瘑鈥?路 鐪佷唤鐗?,
        description: '鐞嗚璇撅細銆愮渷浠界増銆戝鍒欐潗鏂欓槄璇绘€濊矾锝滈€傜敤鐪佷唤锛氬寳浜€佹睙鑻忥綔璧勬簮鐘舵€侊細寰呰ˉ鍏?,
        type: 'video',
        duration: 25,
        completed: 0,
        resources: [],
      }],
    },
    {
      day: 5,
      status: 'in_progress',
      tasks: [{
        name: '[浼樺厛鍕鹃€塢 鍒烽涓€',
        description: '鍗＄偣锛氳鐐逛笉鍏ㄤ笉鍑嗭綔鍒烽浠诲姟',
        type: 'practice',
        duration: 30,
        completed: 1,
        resources: [],
      }],
    },
    {
      day: 6,
      status: 'pending',
      tasks: [{
        name: '[浼樺厛鍕鹃€塢 鍒烽浜?,
        description: '鍗＄偣锛氳鐐逛笉鍏ㄤ笉鍑嗭綔鍒烽浠诲姟',
        type: 'practice',
        duration: 30,
        completed: 0,
        resources: [],
      }],
    },
    {
      day: 7,
      status: 'pending',
      tasks: [{
        name: '[浼樺厛鍕鹃€塢 鍒烽涓?,
        description: '鍗＄偣锛氳鐐逛笉鍏ㄤ笉鍑嗭綔鍒烽浠诲姟',
        type: 'practice',
        duration: 30,
        completed: 0,
        resources: [],
      }],
    },
    {
      day: 8,
      status: 'pending',
      tasks: [{
        name: '[浼樺厛鍕鹃€塢 鍒烽鍥?,
        description: '鍗＄偣锛氳鐐逛笉鍏ㄤ笉鍑嗭綔鍒烽浠诲姟',
        type: 'practice',
        duration: 30,
        completed: 0,
        resources: [],
      }],
    },
    {
      day: 9,
      status: 'pending',
      tasks: [{
        name: '鑰冭瘯',
        description: '鍗＄偣锛氳鐐逛笉鍏ㄤ笉鍑嗭綔闃舵鑰冭瘯',
        type: 'exam',
        duration: 50,
        completed: 0,
        resources: [],
      }],
    },
    {
      day: 10,
      status: 'pending',
      tasks: [{
        name: '[鎵嬪姩鍕鹃€塢 鍒烽x',
        description: '鏇挎崲棰?/ 琛ヨ€冮',
        type: 'practice',
        duration: 30,
        completed: 0,
        resources: [],
      }],
    },
    {
      day: 11,
      status: 'pending',
      tasks: [{
        name: '[鎵嬪姩鍕鹃€塢 鍒烽x锛堢浜屽锛?,
        description: '鏇挎崲棰?/ 琛ヨ€冮',
        type: 'practice',
        duration: 30,
        completed: 0,
        resources: [],
      }],
    },
    {
      day: 12,
      status: 'pending',
      tasks: [{
        name: '浜屾鑰冭瘯',
        description: '鍗＄偣锛氳鐐逛笉鍏ㄤ笉鍑嗭綔浜屾鑰冭瘯',
        type: 'exam',
        duration: 50,
        completed: 0,
        resources: [],
      }],
    },
  ],
}

const students = [
  {
    key: 's1',
    openid: 'dev_openid_001',
    phone: '13800000001',
    name: '寮犳櫒',
    status: 'normal',
    grade: '2026灞?,
    subject: '鐢宠',
    coachKey: 'li',
    diagnosisKey: 'wang',
    managerKey: 'chen',
    principalKey: 'liu',
    lastSession: dateOffset(-1),
    profile: {
      gender: 'male',
      hometown: '鏉窞',
      exam_status: '鍑嗗棣栬€?,
      exam_date: dateOffset(12),
      education: '楂樹腑',
      major: '鐞嗙鏂瑰悜',
      avatar_url: '',
    },
    course: { name: '瑕佺偣涓嶅叏涓嶅噯', progress: 43, status: 'in_progress' },
    noteTexts: [
      '鍗曡瘝鍩虹杩樺彲浠ワ紝浣嗛槄璇诲畾浣嶉€熷害鍋忔參锛岄渶瑕佺户缁仛闄愭椂璁粌銆?,
      '杩欏懆璇惧爞鐘舵€佺ǔ瀹氾紝寤鸿鍛ㄦ湯琛ュ仛涓€濂楃湡棰橀槄璇诲苟鎷嶇収鎻愪氦銆?,
    ],
    flag: null,
    diagnosis: {
      target_exam: '鍥借€冪敵璁?,
      target_score: 130,
      diagnosis_score: 108,
      diagnosis_date: dateOffset(-3),
      teacher_comment: '鍩虹杈冪ǔ锛岀煭鏈熼噸鐐规彁鍗囬槄璇婚€熷害鍜屼綔鏂囪〃杈俱€?,
      points: [
        { point_name: '瑕佺偣涓嶅叏涓嶅噯', priority: 'high', description: '娈佃惤瀹氫綅涓嶅绋冲畾锛屽鏄撳洖鐪嬨€?, sort_order: 1 },
        { point_name: '浣滄枃琛ㄨ揪涓嶇晠', priority: 'medium', description: '鍙ュ紡杈冨崟涓€锛岄渶瑕佸噯澶囨ā鏉裤€?, sort_order: 2 },
      ],
    },
    replayTitle: '鎵剧偣涓嶅叏闈紙浣滀笟璁茶В璇撅級',
    answerTitle: '鍒烽涓€',
    answerScore: 12,
    calendar: [
      { title: '寮犳櫒 鑻辫姝ｈ', date: dateOffset(0), start: '09:00', end: '10:30', type: 'class', link: null },
      { title: '寮犳櫒 闃呰澶嶇洏璇?, date: dateOffset(-1), start: '19:30', end: '20:30', type: 'class', link: 'https://meeting.example.com/teacher-li-1' },
    ],
    chatMessages: [
      ['teacher', '鏉庤€佸笀', '浠婂ぉ璇惧爞鍙嶉宸茬粡鍙戜綘浜嗭紝鏅氱偣璁板緱鐪嬩竴涓嬨€?],
      ['student', '寮犳櫒', '鏀跺埌鑰佸笀锛屾垜鏅氳嚜涔犲悗灏卞紑濮嬫敼銆?],
      ['teacher', '鏉庤€佸笀', '鏀瑰畬鎶?PDF 鎻愪氦涓婃潵锛屾垜鏄庢棭缁欎綘鎵广€?],
    ],
    submissions: [
      {
        id: 'pdf_s1_1',
        reviewType: '鍗＄偣缁冧範棰?,
        checkpoint: '瑕佺偣涓嶅叏涓嶅噯 路 鍒烽涓€',
        deadline: dateTimeOffset(1, '12:00:00'),
        priority: 'normal',
        submittedNormal: 1,
        fileName: '寮犳櫒-瑕佺偣涓嶅叏涓嶅噯-鍒烽涓€.pdf',
        graded: 1,
        score: 12,
        feedback: '瀹氫綅鎬濊矾姝ｇ‘锛岄敊鍦ㄧ粏鑺傝瘝锛屽缓璁户缁檺鏃剁粌涔犮€?,
        gradedAt: dateTimeOffset(-1, '21:00:00'),
        createdAt: dateTimeOffset(-1, '09:30:00'),
      },
    ],
    notification: {
      type: 'class',
      title: '鏄庢棩涓婅鎻愰啋',
      content: '鏄庡ぉ 09:00 鏈夎嫳璇璇撅紝璇锋彁鍓嶅噯澶囧ソ璁蹭箟銆?,
      related_type: 'calendar_event',
      related_id: 'seed_calendar_s1_1',
      scheduled_at: dateTimeOffset(0, '20:00:00'),
    },
    outlineItems: [
      { type: 'listen', content: '鍥炲惉鈥滄壘鐐逛笉鍏ㄩ潰锛堢悊璁烘柟娉曡瑙ｏ級鈥濅笌鈥滀綔涓氳瑙ｈ鈥濄€?, sort_order: 1 },
      { type: 'write', content: '瀹屾垚鈥滃埛棰樹竴鈥濆苟鏁寸悊閿欏洜銆?, sort_order: 2 },
    ],
  },
  {
    key: 's2',
    openid: 'dev_openid_002',
    phone: '13800000002',
    name: '鏉庢偊',
    status: 'new',
    grade: '2026灞?,
    subject: '鐢宠',
    coachKey: 'li',
    diagnosisKey: 'wang',
    managerKey: 'chen',
    principalKey: 'liu',
    lastSession: dateOffset(-2),
    profile: {
      gender: 'female',
      hometown: '瀹佹尝',
      exam_status: '鏂板叆鐝?,
      exam_date: dateOffset(12),
      education: '楂樹腑',
      major: '鏂囩鏂瑰悜',
      avatar_url: '',
    },
    course: { name: '鎻愮偧杞堪鍥伴毦', progress: 18, status: 'in_progress' },
    noteTexts: [
      '鏂扮敓锛岄槄璇诲熀纭€杈冨急锛屽厛浠庢钀藉ぇ鎰忛鍜屼富鏃ㄩ鍏ユ墜銆?,
      '鍙嶉姣旇緝绉瀬锛屼絾鍋氶閫熷害鎱紝寤鸿鍏堜繚鍑嗙‘鐜囥€?,
    ],
    flag: null,
    diagnosis: {
      target_exam: '鍥借€冪敵璁?,
      target_score: 125,
      diagnosis_score: 96,
      diagnosis_date: dateOffset(-4),
      teacher_comment: '閫傚悎浣滀负鏂扮敓鏍蜂緥锛岄噸鐐圭洴鍩虹闃呰鍜屽崟璇嶃€?,
      points: [
        { point_name: '鎻愮偧杞堪鍥伴毦', priority: 'high', description: '鎶撲腑蹇冨彞鑳藉姏杈冨急銆?, sort_order: 1 },
        { point_name: '鍒嗘瀽缁撴瀯涓嶆竻', priority: 'medium', description: '楂橀璇嶄笉鐔燂紝褰卞搷闃呰閫熷害銆?, sort_order: 2 },
      ],
    },
    replayTitle: '闃呰绮剧粌鐝瀛﹁',
    answerTitle: '涓绘棬棰樹笓椤逛竴',
    answerScore: 14,
    calendar: [
      { title: '鏉庢偊 鍏ョ彮璇婃柇璇?, date: dateOffset(1), start: '14:00', end: '15:30', type: 'class', link: null },
      { title: '鏉庢偊 闃呰绮剧粌璇?, date: dateOffset(-2), start: '20:00', end: '21:00', type: 'class', link: 'https://meeting.example.com/teacher-li-2' },
    ],
    chatMessages: [
      ['student', '鏉庢偊', '鑰佸笀鎴戝垰鎶婇槄璇讳綔涓氭暣鐞嗗ソ浜嗐€?],
      ['teacher', '鏉庤€佸笀', '濂界殑锛屾垜鐪嬪埌鍚庝細浼樺厛甯綘鎵规敼銆?],
      ['student', '鏉庢偊', '璋㈣阿鑰佸笀锛屾垜涔熸兂鐭ラ亾鑷繁涓绘棬棰樹负浠€涔堣€侀敊銆?],
    ],
    submissions: [
      {
        id: 'pdf_s2_1',
        reviewType: '鍗＄偣缁冧範棰?,
        checkpoint: '鎻愮偧杞堪鍥伴毦 绗?2 璁?,
        deadline: dateTimeOffset(0, '12:00:00'),
        priority: 'urgent',
        submittedNormal: 1,
        fileName: '鏉庢偊-涓绘棬棰樹笓椤?绗?璁?pdf',
        graded: 0,
        score: null,
        feedback: null,
        gradedAt: null,
        createdAt: dateTimeOffset(0, '08:30:00'),
      },
    ],
    notification: {
      type: 'review',
      title: '鏂颁綔涓氬緟鎵规敼',
      content: '鏉庢偊宸叉彁浜や富鏃ㄩ涓撻」浣滀笟锛岃鍙婃椂鎵规敼銆?,
      related_type: 'submission',
      related_id: 'pdf_s2_1',
      scheduled_at: dateTimeOffset(0, '08:40:00'),
    },
    outlineItems: [
      { type: 'listen', content: '鍥炵湅瀵煎璇句腑涓绘棬棰樺垽鏂柟娉曘€?, sort_order: 1 },
      { type: 'write', content: '鏁寸悊 10 涓珮棰戜富鏃ㄩ淇″彿璇嶃€?, sort_order: 2 },
    ],
    leaveRequest: {
      pointName: '鎻愮偧杞堪鍥伴毦',
      stepName: '绗?2 璁?,
      days: 1,
      reason: '瀛︾敓涓存椂鍙傚姞鏍″唴鑰冭瘯锛岀敵璇烽『寤朵竴澶╀笂璇俱€?,
      status: 'pending',
    },
  },
  {
    key: 's3',
    openid: 'dev_openid_003',
    phone: '13800000003',
    name: '鐜嬫旦',
    status: 'normal',
    grade: '2026灞?,
    subject: '鐢宠',
    coachKey: 'li',
    diagnosisKey: 'wang',
    managerKey: 'chen',
    principalKey: 'liu',
    lastSession: dateOffset(-1),
    profile: {
      gender: 'male',
      hometown: '缁嶅叴',
      exam_status: '鍐插埡闃舵',
      exam_date: dateOffset(26),
      education: '楂樹腑',
      major: '鐞嗙鏂瑰悜',
      avatar_url: '',
    },
    course: { name: '瀵圭瓥鎺ㄥ鍥伴毦', progress: 32, status: 'in_progress' },
    noteTexts: [
      '鍘嬭酱棰橀亣鍒伴€掓帹鍏崇郴鏃跺鏄撳崱浣忥紝闇€瑕佸厛瀛︿細鎷嗘潯浠躲€?,
      '鏈€杩戞彁浜や綔涓氫笉绋冲畾锛屽缓璁妸鏅氶棿澶嶇洏鏃堕棿鍥哄畾涓嬫潵銆?,
    ],
    flag: { flagged: 1, reason: '杩炵画涓ゆ浣滀笟寤舵湡锛屼笖鏈€杩戣鍫傜姸鎬佹尝鍔ㄨ緝澶с€?, severity: 'high' },
    diagnosis: {
      target_exam: '鍥借€冪敵璁?,
      target_score: 128,
      diagnosis_score: 92,
      diagnosis_date: dateOffset(-3),
      teacher_comment: '灞炰簬闇€瑕侀噸鐐硅窡杩涚殑寮傚父瀛︾敓锛屽厛绋充綇浣滀笟鎻愪氦鑺傚銆?,
      points: [
        { point_name: '瀵圭瓥鎺ㄥ鍥伴毦', priority: 'high', description: '鍘嬭酱棰樻媶鍒嗘€濊矾涓嶆竻鏅般€?, sort_order: 1 },
        { point_name: '鍒嗘瀽缁撴瀯涓嶆竻', priority: 'medium', description: '鍒嗙被璁ㄨ瀹规槗婕忔儏鍐点€?, sort_order: 2 },
      ],
    },
    replayTitle: '鏁板垪鍘嬭酱棰樿璇?,
    answerTitle: '鏁板垪缁煎悎璁粌涓€',
    answerScore: 10,
    calendar: [
      { title: '鐜嬫旦 鏁板鍘嬭酱璇?, date: dateOffset(0), start: '16:00', end: '17:00', type: 'class', link: null },
      { title: '鐜嬫旦 鏁板垪璁茶瘎璇?, date: dateOffset(-1), start: '10:00', end: '11:00', type: 'class', link: null },
    ],
    chatMessages: [
      ['student', '鐜嬫旦', '鑰佸笀锛屾垜杩欐鍘嬭酱棰樿繕鏄病鍋氬嚭鏉ャ€?],
      ['teacher', '鏉庤€佸笀', '鍏堟妸宸茬煡鏉′欢鐢绘垚缁撴瀯鍥撅紝鍐嶆寜姝ラ鎷嗐€?],
      ['student', '鐜嬫旦', '濂界殑锛屾垜浠婃櫄鎸変綘璇寸殑閲嶆柊鍐欎竴鐗堛€?],
    ],
    submissions: [
      {
        id: 'pdf_s3_1',
        reviewType: '鍗＄偣缁冧範棰?,
        checkpoint: '瀵圭瓥鎺ㄥ鍥伴毦 绗?3 璁?,
        deadline: dateTimeOffset(0, '10:00:00'),
        priority: 'urgent',
        submittedNormal: 0,
        fileName: '鐜嬫旦-鍘嬭酱棰樿缁?绗?璁?pdf',
        graded: 0,
        score: null,
        feedback: null,
        gradedAt: null,
        createdAt: dateTimeOffset(0, '07:45:00'),
      },
    ],
    notification: {
      type: 'system',
      title: '寮傚父瀛﹀憳鎻愰啋',
      content: '鐜嬫旦宸茶鏍囪涓洪噸鐐硅窡杩涳紝璇峰敖蹇畬鎴愭矡閫氫笌鎵规敼銆?,
      related_type: 'student_flag',
      related_id: 's3',
      scheduled_at: dateTimeOffset(0, '09:00:00'),
    },
    outlineItems: [
      { type: 'listen', content: '鍥炵湅鏁板垪鍘嬭酱棰樻潯浠舵媶鍒嗙ず渚嬨€?, sort_order: 1 },
      { type: 'write', content: '瀹屾垚鏁板垪缁煎悎璁粌绗?2 濂楀苟鎻愪氦銆?, sort_order: 2 },
    ],
    assignmentTask: {
      checkpoint: '鏁板垪缁煎悎',
      detail: '寰呭垎閰嶅帇杞撮涓撻」缁冧範',
    },
  },
  {
    key: 's4',
    openid: 'dev_openid_004',
    phone: '13800000004',
    name: '闄堥洩',
    status: 'normal',
    grade: '2026灞?,
    subject: '鐢宠',
    coachKey: 'li',
    diagnosisKey: 'wang',
    managerKey: 'chen',
    principalKey: 'liu',
    lastSession: dateOffset(-3),
    profile: {
      gender: 'female',
      hometown: '鍢夊叴',
      exam_status: '姝ｅ父瀛︿範涓?,
      exam_date: dateOffset(26),
      education: '楂樹腑',
      major: '鏂囩鏂瑰悜',
      avatar_url: '',
    },
    course: { name: '浣滄枃绔嬫剰涓嶅噯', progress: 24, status: 'in_progress' },
    noteTexts: [
      '浣滄枃瀹￠鍩烘湰鍑嗙‘锛屼絾缁撴瀯灞曞紑浠嶇劧鍋忕煭銆?,
      '鏈懆璇惧爞浜掑姩寰堝ソ锛屽彲浠ラ€愭澧炲姞闄愭椂鍐欎綔棰戠巼銆?,
    ],
    flag: null,
    diagnosis: {
      target_exam: '鍥借€冪敵璁?,
      target_score: 126,
      diagnosis_score: 101,
      diagnosis_date: dateOffset(-6),
      teacher_comment: '閫傚悎浣滀负绋冲畾瀛︿範涓殑姝ｅ父鏍蜂緥銆?,
      points: [
        { point_name: '浣滄枃璁鸿瘉涓嶆竻', priority: 'high', description: '鍒嗚鐐瑰睍寮€涓嶅鍏呭垎銆?, sort_order: 1 },
      ],
    },
    replayTitle: '浣滄枃缁撴瀯璇惧洖鏀?,
    answerTitle: '闄愭椂浣滄枃璁粌涓€',
    answerScore: 11,
    calendar: [
      { title: '闄堥洩 鍐欎綔姝ｈ', date: dateOffset(2), start: '13:30', end: '14:30', type: 'class', link: 'https://meeting.example.com/teacher-li-3' },
      { title: '闄堥洩 浣滄枃璁茶瘎璇?, date: dateOffset(-3), start: '18:30', end: '19:30', type: 'class', link: 'https://meeting.example.com/teacher-li-4' },
    ],
    chatMessages: [
      ['student', '闄堥洩', '鑰佸笀锛屼綔鏂囨彁绾叉垜宸茬粡鎸変綘鐨勮姹傛敼浜嗐€?],
      ['teacher', '鏉庤€佸笀', '鎴戠湅鍒颁簡锛岃繖鐗堢粨鏋勬瘮涓婃娓呮寰堝銆?],
      ['teacher', '鏉庤€佸笀', '涓嬫鍙互鍐嶆妸渚嬪瓙鍐欏緱鏇村叿浣撲竴鐐广€?],
    ],
    submissions: [],
    notification: {
      type: 'homework',
      title: '浣滄枃浣滀笟鎻愰啋',
      content: '浠婃櫄 23:59 鍓嶈瀹屾垚涓€绡?800 瀛楅檺鏃朵綔鏂囥€?,
      related_type: 'study_task',
      related_id: 's4_task_4',
      scheduled_at: dateTimeOffset(0, '12:00:00'),
    },
    outlineItems: [
      { type: 'listen', content: '鍥炵湅浣滄枃缁撴瀯璇句腑鐨勭珛鎰忕ず渚嬨€?, sort_order: 1 },
      { type: 'write', content: '瀹屾垚涓€绡囪璁烘枃骞舵爣鍑虹粨鏋勫眰娆°€?, sort_order: 2 },
    ],
  },
  {
    key: 's5',
    openid: 'dev_openid_005',
    phone: '13800000005',
    name: '璧电',
    status: 'normal',
    grade: '2026灞?,
    subject: '鐢宠',
    coachKey: 'li',
    diagnosisKey: 'wang',
    managerKey: 'chen',
    principalKey: 'liu',
    lastSession: dateOffset(-4),
    profile: {
      gender: 'male',
      hometown: '娓╁窞',
      exam_status: '鍩虹钖勫急',
      exam_date: dateOffset(34),
      education: '楂樹腑',
      major: '鐞嗙鏂瑰悜',
      avatar_url: '',
    },
    course: { name: '鍏枃缁撴瀯涓嶆竻', progress: 8, status: 'in_progress' },
    noteTexts: [
      '鍩虹璁＄畻澶辫杈冨锛屽缓璁厛鍥哄畾姣忔棩 20 鍒嗛挓鍩虹棰樸€?,
      '鏈€杩戜袱鍛ㄧ己灏戜富鍔ㄥ弽棣堬紝閫傚悎鏀惧湪寮傚父瀛﹀憳鍒楄〃涓瀵熴€?,
    ],
    flag: { flagged: 1, reason: '杩戞湡鍑哄嫟姝ｅ父锛屼絾浣滀笟姝ｇ‘鐜囨寔缁亸浣庯紝闇€瑕侀噸鐐圭洴鍩虹銆?, severity: 'medium' },
    diagnosis: {
      target_exam: '鍥借€冪敵璁?,
      target_score: 124,
      diagnosis_score: 88,
      diagnosis_date: dateOffset(-7),
      teacher_comment: '鍩虹钖勫急浣嗛厤鍚堝害灏氬彲锛屽缓璁敤浣庨棬妲涗綔涓氬厛寤虹珛淇″績銆?,
      points: [
        { point_name: '鍏枃缁撴瀯涓嶆竻', priority: 'high', description: '鍑芥暟鍥惧儚涓庢€ц川鎺屾彙涓嶇ǔ銆?, sort_order: 1 },
        { point_name: '浣滄枃琛ㄨ揪涓嶇晠', priority: 'medium', description: '姝ラ涔﹀啓涓嶅畬鏁达紝澶卞垎杈冨銆?, sort_order: 2 },
      ],
    },
    replayTitle: '鍑芥暟鍩虹鍥炴斁',
    answerTitle: '鍩虹璁粌涓€',
    answerScore: 8,
    calendar: [
      { title: '璧电 鏁板鍩虹璇?, date: dateOffset(1), start: '18:30', end: '19:30', type: 'class', link: null },
      { title: '璧电 鍑芥暟鍩虹璁茶瘎', date: dateOffset(-4), start: '20:00', end: '21:00', type: 'class', link: null },
    ],
    chatMessages: [
      ['student', '璧电', '鑰佸笀锛屾垜杩欐鍩虹棰樿繕鏄敊浜嗕笉灏戙€?],
      ['teacher', '鏉庤€佸笀', '娌″叧绯伙紝鎴戜滑鍏堟妸鏈€鍩虹鐨勫嚱鏁伴鍨嬬ǔ浣忋€?],
      ['teacher', '鏉庤€佸笀', '浠婃櫄鎶婇敊棰橀噸鏂版妱涓€閬嶏紝鏄庡ぉ鎴戠户缁湅銆?],
    ],
    submissions: [
      {
        id: 'pdf_s5_1',
        reviewType: '鍗＄偣缁冧範棰?,
        checkpoint: '鍏枃缁撴瀯涓嶆竻 绗?1 璁?,
        deadline: dateTimeOffset(1, '18:00:00'),
        priority: 'low',
        submittedNormal: 0,
        fileName: '璧电-鍩虹棰樿缁?绗?璁?pdf',
        graded: 0,
        score: null,
        feedback: null,
        gradedAt: null,
        createdAt: dateTimeOffset(-1, '22:00:00'),
      },
    ],
    notification: {
      type: 'system',
      title: '鍩虹钖勫急璺熻繘',
      content: '璧电宸插姞鍏ラ噸鐐硅瀵熷悕鍗曪紝璇锋寔缁窡杩涘熀纭€浣滀笟銆?,
      related_type: 'student_flag',
      related_id: 's5',
      scheduled_at: dateTimeOffset(0, '09:10:00'),
    },
    outlineItems: [
      { type: 'listen', content: '鍥炲惉鍑芥暟鍥惧儚鍩虹璇俱€?, sort_order: 1 },
      { type: 'write', content: '瀹屾垚鍩虹璁粌绗?1 濂楀苟鏍囧嚭澶卞垎鐐广€?, sort_order: 2 },
    ],
    assignmentTask: {
      checkpoint: '鍏枃缁撴瀯涓嶆竻',
      detail: '寰呭垎閰嶅熀纭€宸╁浐棰樺崟',
    },
  },
  {
    key: 's6',
    account: '12345678901',
    openid: 'dev_openid_006',
    phone: '12345678901',
    name: '?yo???',
    status: 'normal',
    grade: '2026?',
    subject: '??',
    coachKey: 'li',
    diagnosisKey: 'wang',
    managerKey: 'chen',
    principalKey: 'liu',
    lastSession: dateOffset(-1),
    profile: {
      gender: 'other',
      hometown: '??',
      exam_status: '?????',
      exam_date: dateOffset(30),
      education: '??',
      major: '?????',
      avatar_url: '',
    },
    course: { name: '??????', progress: 28, status: 'in_progress' },
    noteTexts: [
      '?????????????????????????',
      '?????????????????????????',
    ],
    flag: null,
    diagnosis: {
      target_exam: '????',
      target_score: 128,
      diagnosis_score: 102,
      diagnosis_date: dateOffset(-5),
      teacher_comment: '?????????????????????????',
      points: [
        { point_name: '??????', priority: 'high', description: '????????????????', sort_order: 1 },
        { point_name: '??????', priority: 'medium', description: '??????????????', sort_order: 2 },
      ],
    },
    replayTitle: '?????????',
    answerTitle: '???????',
    answerScore: 13,
    calendar: [
      { title: '?yo??? ????', date: dateOffset(1), start: '19:00', end: '20:00', type: 'class', link: 'https://meeting.example.com/teacher-li-6' },
      { title: '?yo??? ????', date: dateOffset(-1), start: '20:00', end: '21:00', type: 'class', link: null },
    ],
    chatMessages: [
      ['teacher', '???', '??????????????????????'],
      ['student', '?yo???', '???????????????'],
      ['teacher', '???', '???????????????'],
    ],
    submissions: [
      {
        id: 'pdf_s6_1',
        reviewType: '?????',
        checkpoint: '?????? ? ???',
        deadline: dateTimeOffset(1, '22:00:00'),
        priority: 'normal',
        submittedNormal: 1,
        fileName: '?yo???-???????.pdf',
        graded: 0,
        score: null,
        feedback: null,
        gradedAt: null,
        createdAt: dateTimeOffset(0, '09:00:00'),
      },
    ],
    notification: {
      type: 'class',
      title: '????????',
      content: '?? 19:00 ?????????????????????',
      related_type: 'calendar_event',
      related_id: 'seed_calendar_s6_1',
      scheduled_at: dateTimeOffset(0, '12:00:00'),
    },
    outlineItems: [
      { type: 'listen', content: '?????????????????', sort_order: 1 },
      { type: 'write', content: '???????????????', sort_order: 2 },
    ],
  }
]

function ensureSamplePdf() {
  if (!fs.existsSync(UPLOADS_DIR)) fs.mkdirSync(UPLOADS_DIR, { recursive: true })
  if (fs.existsSync(SAMPLE_PDF_PATH)) return

  const pdf = `%PDF-1.4
1 0 obj
<< /Type /Catalog /Pages 2 0 R >>
endobj
2 0 obj
<< /Type /Pages /Count 1 /Kids [3 0 R] >>
endobj
3 0 obj
<< /Type /Page /Parent 2 0 R /MediaBox [0 0 595 842] /Contents 4 0 R /Resources << /Font << /F1 5 0 R >> >> >>
endobj
4 0 obj
<< /Length 86 >>
stream
BT
/F1 18 Tf
72 760 Td
(Teacher Workbench Seed PDF) Tj
0 -28 Td
/F1 12 Tf
(Generated for internal testing only.) Tj
ET
endstream
endobj
5 0 obj
<< /Type /Font /Subtype /Type1 /BaseFont /Helvetica >>
endobj
xref
0 6
0000000000 65535 f 
0000000010 00000 n 
0000000063 00000 n 
0000000122 00000 n 
0000000250 00000 n 
0000000387 00000 n 
trailer
<< /Size 6 /Root 1 0 R >>
startxref
457
%%EOF`

  fs.writeFileSync(SAMPLE_PDF_PATH, pdf, 'utf8')
}

async function getId(conn, table, whereColumn, whereValue) {
  const [[row]] = await conn.query(
    `SELECT id FROM ${table} WHERE ${whereColumn} = ? LIMIT 1`,
    [whereValue],
  )
  return row?.id ?? null
}

async function getOrCreateCourse(conn, course) {
  const existingId = await getId(conn, 'courses', 'name', course.name)
  if (existingId) {
    await conn.query(
      'UPDATE courses SET subject = ?, description = ?, price = ?, is_active = 1 WHERE id = ?',
      [course.subject, course.description, course.price, existingId],
    )
    return existingId
  }

  const [result] = await conn.query(
    'INSERT INTO courses (name, subject, description, price) VALUES (?, ?, ?, ?)',
    [course.name, course.subject, course.description, course.price],
  )
  return result.insertId
}

async function deleteForStudents(conn, studentIds) {
  if (studentIds.length === 0) return

  const marks = studentIds.map(() => '?').join(', ')
  await conn.query('DELETE oi FROM order_items oi JOIN orders o ON oi.order_id = o.id WHERE o.student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM orders WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE cm FROM chat_messages cm JOIN chat_rooms cr ON cm.room_id = cr.id WHERE cr.student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM chat_rooms WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE tr FROM task_resources tr JOIN study_tasks st ON tr.task_id = st.id JOIN study_days sd ON st.study_day_id = sd.id WHERE sd.student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE st FROM study_tasks st JOIN study_days sd ON st.study_day_id = sd.id WHERE sd.student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM study_days WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM study_sessions WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE ri FROM review_items ri JOIN reviews r ON ri.review_id = r.id WHERE r.student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM reviews WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM review_point_scores WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM study_time_stats WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM outline_items WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE drp FROM diagnosis_report_points drp JOIN diagnosis_reports dr ON drp.report_id = dr.id WHERE dr.student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM diagnosis_reports WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM pdf_submissions WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM student_submissions WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM notifications WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM student_mailbox_messages WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM student_complaints WHERE student_id IN (' + marks + ')', studentIds)
  try {
    await conn.query('DELETE FROM mailbox_messages WHERE student_id IN (' + marks + ')', studentIds)
  } catch (error) {
    if (error.code !== 'ER_NO_SUCH_TABLE') {
      throw error
    }
  }
  await conn.query('DELETE FROM leave_requests WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM student_notes WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM student_flags WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM practice_assignment_tasks WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM lesson_materials WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM calendar_events WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM student_team_members WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM teacher_students WHERE student_id IN (' + marks + ')', studentIds)
  await conn.query('DELETE FROM student_courses WHERE student_id IN (' + marks + ')', studentIds)
}

async function deleteSeedStudents(conn, openids) {
  if (openids.length === 0) return

  const marks = openids.map(() => '?').join(', ')
  const [rows] = await conn.query(
    'SELECT id FROM students WHERE openid IN (' + marks + ')',
    openids,
  )
  const studentIds = rows.map((row) => row.id).filter(Boolean)
  if (studentIds.length === 0) return

  await deleteForStudents(conn, studentIds)

  const idMarks = studentIds.map(() => '?').join(', ')
  await conn.query('DELETE FROM student_profiles WHERE student_id IN (' + idMarks + ')', studentIds)
  await conn.query('DELETE FROM students WHERE id IN (' + idMarks + ')', studentIds)
}

function buildDefaultStudyPlan(studentName, courseName, studentId) {
  return [
    {
      day: 1,
      status: 'completed',
      tasks: [{ name: `${courseName} 寮€鐝洿鎾璥, type: 'live', duration: 60, completed: 1, resources: [] }],
    },
    {
      day: 2,
      status: 'completed',
      tasks: [{
        name: `${courseName} 鏍稿績鏂规硶璇綻,
        type: 'video',
        duration: 45,
        completed: 1,
        resources: [
          { resource_type: 'pdf', phase: 'pre', title: `${studentName}-${courseName}-璁蹭箟`, url: '/uploads/' + SAMPLE_PDF_NAME, video_id: null },
          { resource_type: 'video', phase: 'main', title: `${courseName} 鏂规硶璁茶В`, url: null, video_id: `video_${studentId}_core` },
        ],
      }],
    },
    {
      day: 3,
      status: 'completed',
      tasks: [{ name: `${courseName} 璇惧爞缁冧範`, type: 'practice', duration: 40, completed: 1, resources: [] }],
    },
    {
      day: 4,
      status: 'in_progress',
      tasks: [
        { name: `${courseName} 璇惧悗浣滀笟 1`, type: 'practice', duration: 35, completed: 1, resources: [] },
        {
          name: `${courseName} 閿欓璁茶瘎`,
          type: 'review',
          duration: 20,
          completed: 0,
          resources: [{ resource_type: 'video', phase: 'post', title: `${courseName} 澶嶇洏瑙嗛`, url: null, video_id: `video_${studentId}_review` }],
        },
      ],
    },
    {
      day: 5,
      status: 'pending',
      tasks: [{ name: `${courseName} 璇惧悗浣滀笟 2`, type: 'submit', duration: 20, completed: 0, resources: [] }],
    },
  ]
}

async function insertStudyPlan(conn, studentId, courseId, studentName, courseName) {
  const dayPlan = courseStudyBlueprints[courseName] || buildDefaultStudyPlan(studentName, courseName, studentId)

  for (const day of dayPlan) {
    await conn.query(
      'INSERT INTO study_days (student_id, course_id, day_number, status) VALUES (?, ?, ?, ?)',
      [studentId, courseId, day.day, day.status],
    )
    const [[studyDay]] = await conn.query(
      'SELECT id FROM study_days WHERE student_id = ? AND course_id = ? AND day_number = ?',
      [studentId, courseId, day.day],
    )

    for (let index = 0; index < day.tasks.length; index += 1) {
      const task = day.tasks[index]
      const [taskResult] = await conn.query(
        'INSERT INTO study_tasks (study_day_id, name, description, type, duration_min, completed, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [studyDay.id, task.name, task.description || null, task.type, task.duration, task.completed, index],
      )

      for (let resourceIndex = 0; resourceIndex < task.resources.length; resourceIndex += 1) {
        const resource = task.resources[resourceIndex]
        await conn.query(
          'INSERT INTO task_resources (task_id, resource_type, phase, title, url, video_id, sort_order) VALUES (?, ?, ?, ?, ?, ?, ?)',
          [taskResult.insertId, resource.resource_type, resource.phase, resource.title, resource.url, resource.video_id, resourceIndex],
        )
      }
    }
  }
}

function getMailboxSeedRows(studentKey) {
  if (studentKey === 's1') {
    return [
      {
        category: '鏁欏寤鸿',
        content: '寤鸿鍦ㄩ槄璇昏缁冨墠鍔犱竴娆℃枃绔犲畾浣嶅皬娴嬶紝鏂逛究鎴戝厛鎵惧埌鍏抽敭鍙ャ€?,
        anonymous: 0,
        status: 'pending',
      },
    ]
  }

  if (studentKey === 's5') {
    return [
      {
        category: '鏈嶅姟鎶曡瘔',
        content: '甯屾湜鍔犲揩鍩虹宸╁浐浣滀笟鐨勬壒鏀归鐜囷紝杩欏懆鎯冲敖蹇煡閬撹嚜宸辩殑钖勫急鐐广€?,
        anonymous: 1,
        status: 'read',
      },
    ]
  }

  return []
}

function getExtraSeedNotifications(studentKey) {
  if (studentKey !== 's2') {
    return []
  }

  return [
    {
      type: 'system',
      title: '鍏堝仛 1v1 璇婃柇锛屽啀瀹氬悗缁绋?,
      content: '鍏堢敤浜哄伐璇婃柇鎵惧埌浣犵幇鍦ㄤ富瑕佺殑澶卞垎鐥呭洜锛屽啀鍐冲畾鍚庨潰搴旇鎬庝箞瀛︺€?,
      related_type: 'diagnose_detail',
      related_id: 'diagnose_intro_s2',
      scheduled_at: dateTimeOffset(-1, '18:30:00'),
    },
    {
      type: 'system',
      title: '鏂扮敤鎴疯瘖鏂浼樻儬宸插彂鏀?,
      content: '浣犵殑璇婃柇璇句紭鎯犲凡缁忓彂鏀撅紝鐜板湪鍙互鍏堢湅鏍蜂緥鍐嶅喅瀹氭槸鍚﹁喘涔般€?,
      related_type: 'diagnose_coupon',
      related_id: 'diagnose_coupon_s2',
      scheduled_at: dateTimeOffset(-1, '18:32:00'),
    },
  ]
}

async function seed() {
  execFileSync(process.execPath, [path.join(__dirname, 'init.js')], {
    stdio: 'inherit',
    env: process.env,
  })

  ensureSamplePdf()

  const conn = await mysql.createConnection(getDbConfig())
  console.log('寮€濮嬪啓鍏ヨ€佸笀宸ヤ綔鍙?seed 鏁版嵁...')

  await deleteSeedStudents(conn, [
    'dev_openid_001',
    'dev_openid_002',
    'dev_openid_003',
    'dev_openid_004',
    'dev_openid_005',
    'dev_openid_006',
    'dev_openid_007',
    'dev_openid_008',
  ])

  const passwordHash = await bcrypt.hash('123456', 10)
  const teacherIds = {}

  for (const teacher of teachers) {
    await conn.query(
      'INSERT INTO teachers (name, email, password_hash, title) VALUES (?, ?, ?, ?) ON DUPLICATE KEY UPDATE name = VALUES(name), password_hash = VALUES(password_hash), title = VALUES(title)',
      [teacher.name, teacher.email, passwordHash, teacher.title],
    )
    teacherIds[teacher.key] = await getId(conn, 'teachers', 'email', teacher.email)
  }

  const studentIds = {}
  for (const student of students) {
    await conn.query(
      'INSERT INTO students (openid, account, phone, password_hash, name, status) VALUES (?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE account = VALUES(account), phone = VALUES(phone), password_hash = VALUES(password_hash), name = VALUES(name), status = VALUES(status)',
      [student.openid, student.account || student.key, student.phone, passwordHash, student.name, student.status],
    )
    const studentId = await getId(conn, 'students', 'openid', student.openid)
    studentIds[student.key] = studentId
    await conn.query(
      'INSERT INTO student_profiles (student_id, gender, grade, hometown, exam_status, exam_date, education, major, avatar_url) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE gender = VALUES(gender), grade = VALUES(grade), hometown = VALUES(hometown), exam_status = VALUES(exam_status), exam_date = VALUES(exam_date), education = VALUES(education), major = VALUES(major), avatar_url = VALUES(avatar_url)',
      [
        studentId,
        student.profile.gender,
        student.grade,
        student.profile.hometown,
        student.profile.exam_status,
        student.profile.exam_date,
        student.profile.education,
        student.profile.major,
        student.profile.avatar_url,
      ],
    )
  }

  await deleteForStudents(conn, Object.values(studentIds))

  const courseIds = {}
  for (const course of courseCatalog) {
    courseIds[course.name] = await getOrCreateCourse(conn, course)
  }

  const primaryTeacherId = teacherIds[PRIMARY_TEACHER_KEY]
  const primaryTeacherName = teachers.find((item) => item.key === PRIMARY_TEACHER_KEY)?.name ?? '鏉庤€佸笀'
  await conn.query(
    'DELETE FROM calendar_events WHERE teacher_id = ? AND student_id IS NULL',
    [primaryTeacherId],
  )

  for (const student of students) {
    const studentId = studentIds[student.key]
    const coachId = teacherIds[student.coachKey]
    const diagnosisId = teacherIds[student.diagnosisKey]
    const managerId = teacherIds[student.managerKey]
    const principalId = teacherIds[student.principalKey]
    const courseId = courseIds[student.course.name]

    await conn.query(
      'INSERT INTO teacher_students (teacher_id, student_id, subject, grade) VALUES (?, ?, ?, ?)',
      [primaryTeacherId, studentId, student.subject, student.grade],
    )

    const teamMembers = [
      [coachId, 'coach'],
      [diagnosisId, 'diagnosis'],
      [managerId, 'manager'],
      [principalId, 'principal'],
    ]
    for (const [teacherId, role] of teamMembers) {
      await conn.query(
        'INSERT INTO student_team_members (student_id, teacher_id, role, status) VALUES (?, ?, ?, ?)',
        [studentId, teacherId, role, 'assigned'],
      )
    }

    await conn.query(
      'INSERT INTO student_courses (student_id, course_id, progress, status) VALUES (?, ?, ?, ?)',
      [studentId, courseId, student.course.progress, student.course.status],
    )
    await insertStudyPlan(conn, studentId, courseId, student.name, student.course.name)

    for (const noteText of student.noteTexts) {
      await conn.query(
        'INSERT INTO student_notes (teacher_id, student_id, content, author) VALUES (?, ?, ?, ?)',
        [primaryTeacherId, studentId, noteText, primaryTeacherName],
      )
    }

    if (student.flag) {
      await conn.query(
        'INSERT INTO student_flags (teacher_id, student_id, flagged, reason, severity) VALUES (?, ?, ?, ?, ?)',
        [primaryTeacherId, studentId, student.flag.flagged, student.flag.reason, student.flag.severity],
      )
    }

    await conn.query(
      'INSERT INTO diagnosis_reports (student_id, teacher_id, target_exam, target_score, diagnosis_score, score_gap, diagnosis_date, teacher_comment) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
      [
        studentId,
        diagnosisId,
        student.diagnosis.target_exam,
        student.diagnosis.target_score,
        student.diagnosis.diagnosis_score,
        student.diagnosis.target_score - student.diagnosis.diagnosis_score,
        student.diagnosis.diagnosis_date,
        student.diagnosis.teacher_comment,
      ],
    )
    const [[report]] = await conn.query(
      'SELECT id FROM diagnosis_reports WHERE student_id = ? ORDER BY id DESC LIMIT 1',
      [studentId],
    )
    for (const point of student.diagnosis.points) {
      await conn.query(
        'INSERT INTO diagnosis_report_points (report_id, course_id, point_name, priority, description, sort_order) VALUES (?, ?, ?, ?, ?, ?)',
        [report.id, courseId, point.point_name, point.priority, point.description, point.sort_order],
      )
    }

    const reviewPointScores = student.reviewPointScores || buildDefaultReviewPointScores(student)
    for (const pointRow of reviewPointScores) {
      await conn.query(
        `INSERT INTO review_point_scores (student_id, point_name, current_rate, target_rate, source_type, sort_order)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [
          studentId,
          pointRow.point_name,
          pointRow.current_rate,
          pointRow.target_rate,
          pointRow.source_type || 'diagnosis',
          pointRow.sort_order || 0,
        ],
      )
    }

    const studyTimeStats = student.studyTimeStats || buildDefaultStudyTimeStats()
    for (const statRow of studyTimeStats) {
      await conn.query(
        `INSERT INTO study_time_stats (student_id, period_key, period_label, hours, cycle_type, sort_order)
         VALUES (?, ?, ?, ?, ?, ?)`,
        [
          studentId,
          statRow.period_key,
          statRow.period_label,
          statRow.hours,
          statRow.cycle_type || 'week',
          statRow.sort_order || 0,
        ],
      )
    }

    await conn.query(
      'INSERT INTO reviews (student_id, teacher_id, course_id, target_score, gained_score, feedback) VALUES (?, ?, ?, ?, ?, ?)',
      [studentId, primaryTeacherId, courseId, 20, student.answerScore, `${student.course.name} 鏈懆澶嶇洏宸茬敓鎴恅],
    )
    const [[review]] = await conn.query(
      'SELECT id FROM reviews WHERE student_id = ? ORDER BY id DESC LIMIT 1',
      [studentId],
    )
    await conn.query(
      'INSERT INTO review_items (review_id, type, content, completed, sort_order) VALUES (?, ?, ?, ?, ?)',
      [review.id, 'listen', `${student.replayTitle} 鍥炲惉`, 1, 1],
    )
    await conn.query(
      'INSERT INTO review_items (review_id, type, content, completed, sort_order) VALUES (?, ?, ?, ?, ?)',
      [review.id, 'write', `${student.answerTitle} 璁㈡`, 0, 2],
    )

    for (const item of student.outlineItems) {
      await conn.query(
        'INSERT INTO outline_items (student_id, course_id, type, content, completed, sort_order) VALUES (?, ?, ?, ?, ?, ?)',
        [studentId, courseId, item.type, item.content, 0, item.sort_order],
      )
    }

    const [orderResult] = await conn.query(
      'INSERT INTO orders (student_id, total_amount, status, paid_at) VALUES (?, ?, ?, NOW())',
      [studentId, 1080, 'paid'],
    )
    await conn.query(
      'INSERT INTO order_items (order_id, course_id, course_name_snapshot, price) VALUES (?, ?, ?, ?)',
      [orderResult.insertId, courseId, student.course.name, 1080],
    )

    const calendarEventIds = []
    for (const event of student.calendar) {
      const [eventResult] = await conn.query(
        'INSERT INTO calendar_events (teacher_id, student_id, title, date, start_time, end_time, type, link) VALUES (?, ?, ?, ?, ?, ?, ?, ?)',
        [primaryTeacherId, studentId, event.title, event.date, event.start, event.end, event.type, event.link],
      )
      calendarEventIds.push(eventResult.insertId)
    }

    if (student.assignmentTask) {
      await conn.query(
        'INSERT INTO practice_assignment_tasks (teacher_id, student_id, checkpoint, detail, status) VALUES (?, ?, ?, ?, ?)',
        [primaryTeacherId, studentId, student.assignmentTask.checkpoint, student.assignmentTask.detail, 'pending'],
      )
    }

    if (student.key === 's1' && calendarEventIds[1]) {
      await conn.query(
        `INSERT INTO lesson_materials (teacher_id, student_id, calendar_event_id, material_type, title, url)
         VALUES (?, ?, ?, 'replay', ?, ?)` ,
        [primaryTeacherId, studentId, calendarEventIds[1], `璇剧▼鍥炴斁锛?{student.calendar[1].title}`, 'https://meeting.example.com/replay-s1'],
      )
      await conn.query(
        `INSERT INTO lesson_materials (teacher_id, student_id, calendar_event_id, material_type, title, file_name, stored_file)
         VALUES (?, ?, ?, 'handout', ?, ?, ?)` ,
        [primaryTeacherId, studentId, calendarEventIds[1], `璇惧悗璁蹭箟锛?{student.calendar[1].title}`, `${student.name}-璇惧悗璁蹭箟.pdf`, SAMPLE_PDF_NAME],
      )
    }

    const [roomResult] = await conn.query(
      'INSERT INTO chat_rooms (teacher_id, student_id) VALUES (?, ?)',
      [primaryTeacherId, studentId],
    )
    for (const [senderType, senderName, content] of student.chatMessages) {
      const senderId = senderType === 'teacher' ? primaryTeacherId : studentId
      await conn.query(
        'INSERT INTO chat_messages (room_id, sender_type, sender_id, sender_name, content, type) VALUES (?, ?, ?, ?, ?, ?)',
        [roomResult.insertId, senderType, senderId, senderName, content, 'text'],
      )
    }

    for (const submission of student.submissions) {
      await conn.query(
        'INSERT INTO pdf_submissions (id, student_id, student_name, review_type, checkpoint, deadline, priority, submitted_normal, file_name, stored_file, graded, score, feedback, graded_at, created_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
          submission.id,
          studentId,
          student.name,
          submission.reviewType,
          submission.checkpoint,
          submission.deadline,
          submission.priority,
          submission.submittedNormal,
          submission.fileName,
          SAMPLE_PDF_NAME,
          submission.graded,
          submission.score,
          submission.feedback,
          submission.gradedAt,
          submission.createdAt,
        ],
      )
    }

    const notifications = [
      ...(student.notification ? [student.notification] : []),
      ...getExtraSeedNotifications(student.key),
    ]
    for (const notification of notifications) {
      await conn.query(
        'INSERT INTO notifications (student_id, type, title, content, related_type, related_id, scheduled_at) VALUES (?, ?, ?, ?, ?, ?, ?)',
        [
          studentId,
          notification.type,
          notification.title,
          notification.content,
          notification.related_type,
          notification.related_id,
          notification.scheduled_at,
        ],
      )
    }

    if (student.leaveRequest) {
      await conn.query(
        'INSERT INTO leave_requests (student_id, type, course_id, point_name, step_name, days, reason, status, reviewed_by, approved_at) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)',
        [
          studentId,
          'single',
          courseId,
          student.leaveRequest.pointName,
          student.leaveRequest.stepName,
          student.leaveRequest.days,
          student.leaveRequest.reason,
          student.leaveRequest.status,
          student.leaveRequest.status === 'pending' ? null : managerId,
          student.leaveRequest.status === 'pending' ? null : new Date(),
        ],
      )
    }

    for (const mailboxRow of getMailboxSeedRows(student.key)) {
      await conn.query(
        'INSERT INTO student_mailbox_messages (student_id, category, content, anonymous, status) VALUES (?, ?, ?, ?, ?)',
        [studentId, mailboxRow.category, mailboxRow.content, mailboxRow.anonymous, mailboxRow.status]
      )
    }

    await conn.query(
      'INSERT INTO study_sessions (student_id, course_id, session_type, status, started_at, ended_at, duration_sec) VALUES (?, ?, ?, ?, ?, ?, ?)',
      [studentId, courseId, 'lesson', 'completed', `${student.lastSession} 19:00:00`, `${student.lastSession} 20:00:00`, 3600],
    )
  }

  console.log('\n鑰佸笀宸ヤ綔鍙版祴璇曟暟鎹啓鍏ュ畬鎴愩€?)
  console.log(`鏁欏笀鐧诲綍锛歭i@test.com / 123456`)
  console.log(`瀛︾敓璐﹀彿锛?{students.map((student) => `${student.name}(${student.openid})`).join('锛?)}`)
  console.log(`寰呮壒鏀?PDF锛歱df_s2_1锛宲df_s3_1锛宲df_s5_1`)
  console.log(`寮傚父瀛﹀憳锛氱帇娴╋紝璧电`)
  console.log(`绀轰緥 PDF锛?{SAMPLE_PDF_PATH}`)
  await conn.end()
}

seed().catch((err) => {
  console.error('鍐欏叆澶辫触锛?, err.message)
  process.exit(1)
})

